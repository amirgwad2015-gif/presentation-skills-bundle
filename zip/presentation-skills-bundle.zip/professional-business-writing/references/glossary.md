# Financial glossary - Arabic / English (use one term consistently)

## Income statement
| English | العربية المعتمدة | Avoid mixing with |
|---|---|---|
| Revenue / Net sales | الإيرادات / صافي المبيعات | الدخل، العوائد |
| Cost of goods sold (COGS) | تكلفة المبيعات | تكلفة البضاعة، المصروفات المباشرة |
| Gross profit / Gross margin | مجمل الربح / هامش مجمل الربح | الربح الإجمالي |
| Operating expenses (OPEX) | المصروفات التشغيلية | النفقات |
| SG&A | المصروفات البيعية والعمومية والإدارية | |
| EBITDA | EBITDA (الأرباح قبل الفوائد والضرائب والإهلاك والاستهلاك) | |
| EBIT / Operating profit | الربح التشغيلي | |
| Depreciation & amortization | الإهلاك والاستهلاك | |
| Finance cost / Interest expense | تكلفة التمويل / مصروف الفوائد | |
| Net profit | صافي الربح | صافي الدخل |
| Net margin | هامش صافي الربح | |

## Balance sheet
| English | العربية |
|---|---|
| Total assets | إجمالي الأصول |
| Fixed assets (PP&E) | الأصول الثابتة |
| Current assets / liabilities | الأصول المتداولة / الالتزامات المتداولة |
| Inventory | المخزون |
| Trade receivables | العملاء / المدينون التجاريون |
| Trade payables | الموردون / الدائنون التجاريون |
| Working capital | رأس المال العامل |
| Equity | حقوق الملكية |
| Total debt / Net debt | إجمالي الدين / صافي الدين |
| Short-term / Long-term loans | قروض قصيرة الأجل / طويلة الأجل |
| Credit facility | تسهيل ائتماني |

## Cash flow & valuation
| English | العربية |
|---|---|
| Operating cash flow | التدفق النقدي من الأنشطة التشغيلية |
| Free cash flow (FCF) | التدفق النقدي الحر |
| CAPEX | الإنفاق الرأسمالي |
| Debt service | خدمة الدين |
| DSCR | نسبة تغطية خدمة الدين (DSCR) |
| Net debt / EBITDA | صافي الدين إلى EBITDA |
| Current ratio | نسبة التداول |
| Leverage | الرافعة المالية |
| IRR / NPV | معدل العائد الداخلي (IRR) / صافي القيمة الحالية (NPV) |
| Payback period | فترة الاسترداد |
| WACC | المتوسط المرجح لتكلفة رأس المال (WACC) |
| Enterprise value | قيمة المنشأة |
| Valuation | التقييم |

## Operations & plans
| English | العربية |
|---|---|
| Capacity utilisation | نسبة استغلال الطاقة / الطاقة المستغلة |
| Turnaround plan | خطة إعادة الهيكلة / خطة التعافي |
| Action plan | خطة تنفيذية / خطة عمل |
| KPI | مؤشر أداء رئيسي (KPI) |
| Budget vs actual | الموازنة مقابل الفعلي |
| Variance | الانحراف |
| Year-on-year (YoY) | مقارنة بالعام السابق |
| Year to date (YTD) | منذ بداية العام |
| CAGR | معدل النمو السنوي المركب |
| Base case / Downside | السيناريو الأساسي / السيناريو المتحفظ |
| Sensitivity analysis | تحليل الحساسية |
| Risks and mitigants | المخاطر وإجراءات الحد منها |
| Use of funds | أوجه استخدام التمويل |
| Repayment schedule | جدول السداد |
| Grace period | فترة السماح |
| Collateral | الضمانات |

## Words to simplify (Arabic)
| بدلاً من | اكتب |
|---|---|
| قام بعمل دراسة | درس |
| تم القيام بتخفيض | خفّضنا / انخفض |
| في ضوء ما سبق | لذلك |
| على الرغم من أن | رغم أن |
| بشكل كبير جداً | (اذكر الرقم) |
| يعتبر من أهم | من أهم |
| العمل على تحقيق | تحقيق |
| من خلال القيام بـ | عبر / بـ |
| وذلك نظراً لـ | بسبب |
| الجدير بالذكر أن | (احذفها) |
