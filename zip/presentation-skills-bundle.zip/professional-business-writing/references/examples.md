# Before / after examples

## Slide titles
| Before | After |
|---|---|
| الإيرادات | الإيرادات نمت 18.0% في 2025 بدعم زيادة الكميات |
| تحليل الهوامش | هامش مجمل الربح ارتفع 2.1 نقطة مئوية بعد إعادة التسعير |
| الوضع المالي للشركة | المديونية انخفضت إلى 2.1x من EBITDA وتسمح بتمويل التوسع |
| Revenue analysis | Revenue grew 18.0% in 2025, driven by volume |

## Bullets
Before:
- تم العمل على تخفيض المخزون بشكل كبير خلال الفترة الماضية مما أدى إلى تحسن السيولة
- كذلك فقد قامت الإدارة بإعادة التفاوض مع الموردين
- زيادة المبيعات للتصدير

After:
- خفض المخزون 15.0% وتحرير 42 مليون جنيه سيولة
- مد فترة سداد الموردين من 45 إلى 60 يومًا
- رفع التصدير إلى 30.0% من المبيعات

## Paragraph (bank memo)
Before:
"في واقع الأمر فإن الشركة قد شهدت خلال العام المنصرم تحسنًا ملحوظًا في أدائها المالي وذلك نظرًا لما قامت به الإدارة من مجهودات كبيرة في سبيل ضبط التكاليف وزيادة المبيعات، ومن ثم فإن الشركة تتقدم بطلب الحصول على تسهيل ائتماني."

After:
"تطلب الشركة تسهيلًا ائتمانيًا متوسط الأجل بقيمة 150 مليون جنيه لمدة 5 سنوات لتمويل خط إنتاج جديد. تحسن الأداء في 2025: نمت الإيرادات 18.0% وارتفع هامش EBITDA إلى 14.2%، ما يرفع تغطية خدمة الدين إلى 1.6x."

(What changed: the request comes first, vague words replaced with numbers, 58 words → 42 words.)

## Ranges and percentages (RTL)
| Wrong | Right |
|---|---|
| 10%-15% | من 10.0% إلى 15.0% |
| نمو 5% - 7% | نمو من 5.0% إلى 7.0% |
| الهامش زاد 2% (from 12% to 14%) | الهامش زاد نقطتين مئويتين (من 12.0% إلى 14.0%) |
| 1,250.45 مليون | 1,250 مليون |
| 18.25% | 18.3% |

## English
Before: "It is important to note that the company has been able to achieve a significant improvement in its margins due to the fact that management implemented cost-cutting initiatives."
After: "Margins improved 2.1 pp after management cut raw-material costs 8.0%."
