---
name: professional-business-writing
description: Keep all business writing professional yet simple - in Arabic (clear Modern Standard Arabic) and English - for presentations, slide titles and bullets, reports, bank and board memos, business plans, emails and summaries. Enforces short clear sentences, message-first structure, consistent financial terminology, correct number/percentage formatting and correct right-to-left handling of Arabic text mixed with numbers and English terms. Use this skill whenever writing or rewriting any text that will be read by management, banks, investors or clients, whenever slide text is drafted, and whenever the user asks to rephrase, polish, simplify or proofread (صياغة، إعادة صياغة، تبسيط، مراجعة لغوية، كتابة احترافية).
---

# Professional & Simple Business Writing

The reader is busy and senior (bank credit committee, board, CEO). They should get the point from the
first sentence and never have to re-read. Professional does not mean complicated: the most
professional text is the one that is precise, short and easy.

## Core rules (both languages)
1. **Message first.** Start with the conclusion, then the evidence, then the detail.
   Slide titles are full-sentence conclusions ("الإيرادات نمت 18.0% بدعم زيادة الكميات"), not topics ("الإيرادات").
2. **One idea per sentence, one message per slide/paragraph.** Sentences ≤ 20 words; bullets ≤ 12 words.
3. **Concrete over vague.** Replace "تحسن ملحوظ" with the number: "تحسن الهامش 1.3 نقطة".
   Every claim that can be quantified is quantified, with unit and period.
4. **Active voice, strong verbs.** "خفضنا المخزون 15.0%" rather than "تم العمل على تخفيض المخزون".
5. **Parallel structure.** Bullets in a list start the same way (all verbs or all nouns) and have similar length.
6. **Cut filler.** Remove: "من الجدير بالذكر أن"، "في واقع الأمر"، "قام بـ"، "بشكل كبير جداً"، "it is important to note that", "in order to".
7. **Consistent terms.** Pick one term per concept and keep it (see `references/glossary.md`).
   Don't alternate "الإيرادات/المبيعات/الدخل" for the same line item.
8. **Neutral, confident tone.** No exaggeration ("طفرة غير مسبوقة"), no hedging chains. Risks are
   stated plainly with their mitigation.
9. **Sources.** Every figure has a source line on the slide / in a footnote.

## Arabic style: فصحى مبسطة
- Modern Standard Arabic, business register, no colloquial Egyptian in formal documents (unless the
  user asks). Short sentences, common words: "زيادة" not "تصاعد مطرد"، "بسبب" not "نظرًا لما سبق".
- Avoid starting every sentence with "تم" + masdar; use the direct verb.
- Use Arabic punctuation: comma "،", semicolon "؛", question mark "؟". Put no space before punctuation.
- English acronyms that professionals use as-is stay in English: EBITDA, DSCR, IRR, NPV, KPI, ERP.
  On first use in a formal document you may add the Arabic between parentheses.
- Company/product names stay as the company writes them.
- Numbers: Western digits (0-9) - the user's convention - with thousands separators.
- Bullets and slide text: no full stop at the end of bullets; titles without a trailing period.

## Numbers and percentages (user defaults - apply everywhere)
- Amounts: no decimals, thousands separator → 1,250 ; 38,400.
- Percentages: exactly one decimal → 18.0% ; 4.5% ; 0.8%.
- Percentage-point changes: "1.3 نقطة مئوية" / "1.3 pp" - never "1.3%" for a change in a ratio.
- Multiples: 2.1x.  Negative amounts in tables: (838).  Growth: "+18.0%" or "▲ 18.0%".
- Units once, in the title/header: "(مليون جنيه)" / "(EGP m)". Don't mix millions and thousands on one slide.
- Periods: "2025" for a year, "الربع الثالث 2026" / "Q3 2026", "9 أشهر 2026" for YTD.
- Numbers and percentages in tables are centered.

## Right-to-left correctness (Arabic text with numbers/English)
The paragraph direction must be RTL (the presentation skill sets it). Then:
- **Ranges read right-to-left**: write "من 10.0% إلى 15.0%" (best) or "10.0% – 15.0%" with spaces
  around an en dash. Never "10.0%-15.0%" (the bidi algorithm keeps it left-to-right).
  In a table range cell the smaller value must appear on the right.
- A percent after a number at the end of an Arabic sentence displays as "%25.0" - that is standard
  Arabic rendering; don't "fix" it by reordering characters.
- Don't start an Arabic line with an English word or number if you can avoid it (the line can look
  left-aligned in some viewers); start with an Arabic word: "نسبة EBITDA بلغت 14.2%".
- Parentheses and brackets: type them normally - they mirror automatically in RTL.
- Don't wrap a lone number or percentage in parentheses inside Arabic text ("تمويل ذاتي (25.0%)") -
  the brackets can visually detach; write "تمويل ذاتي بنسبة 25.0%". Same for chart legends and
  labels that mix Arabic, English and brackets ("EBITDA (مليون جنيه)"): prefer "EBITDA بالمليون جنيه"
  or put the unit in the slide title.
- Avoid slashes between Arabic and English ("صافي الدين / EBITDA") - write "صافي الدين إلى EBITDA".
- Dates: "سبتمبر 2026" or "30 سبتمبر 2026"; avoid 30/09/2026 in running Arabic text.

## Slide writing patterns
- **Action title (≤ 2 lines)**: [what happened] + [how much] + [why / so what].
  "هامش مجمل الربح ارتفع إلى 33.0% بعد إعادة تسعير المنتجات الرئيسية"
- **Kicker** above the title (section name, 1-3 words): "ملخص تنفيذي".
- **Bullets**: lead with the number or the verb. 3-5 bullets. Bold only the key phrase of each.
- **Key-message box**: one sentence that the audience should repeat after the meeting.
- **The ask** (bank decks): amount, instrument, tenor, purpose, repayment source in one slide.

## Workflow when rewriting user text
1. Identify the audience and the single message.
2. Restructure (message → evidence → detail), then shorten sentences, then fix terms and numbers.
3. Check every number against the source; never change a figure while polishing.
4. Return the improved text; if changes are substantial, list the 2-3 main changes briefly.

See `references/examples.md` for before/after rewrites and `references/glossary.md` for the
Arabic–English financial glossary.
