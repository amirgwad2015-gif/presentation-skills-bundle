# Infographic components

All components live in `assets/infographics.html` (CSS block + markup per component). They are built
only from things the converter turns into native PowerPoint shapes: boxes with fills/borders/radius,
text, preset shapes (`data-shape`), and inline SVG icons (become PNGs).

| # | Component | Use it for | Notes |
|---|---|---|---|
| 1 | KPI tile (`.kpi`) | 2-4 headline numbers with change vs prior period | Value big, label small above, delta colored `.up`/`.down`. Colored start border marks status. |
| 2 | Progress / share bars (`.pbar-*`) | utilisation, % of target, market share of few items | Set the fill `width:%` = the value. Fill starts at the inline-start side (right in Arabic). |
| 3 | Numbered steps (`.steps`) | 3-6 stage process with short captions | Connector is a thin box behind circles. Order follows reading direction automatically. |
| 4 | Timeline (`.tl`) | milestones, project plan, repayment schedule | Position milestones with `inset-inline-start`, earliest first. |
| 5 | Icon rows (`.irow`) | drivers, pillars, benefits (3-5) | Icons: 24 px inline SVG, stroke in primary color, one style per deck. |
| 6 | Funnel (`.fl` + `data-shape="trapezoid" data-flip-v`) | pipeline, conversion, from market size to target | Each level narrower; text is put in its own box so it isn't flipped. |
| 7 | Big-number callout (`.callout`) | the one figure the audience must remember (covenant, IRR, payback) | Accent color for the number on primary background. |
| 8 | Status pills (`.pill .hi/.md/.lo`) | risk level, RAG status in tables and lists | Keep label to one word. |
| 9 | Comparison columns (`.cmp`) | before/after, current vs plan, option A vs B | Same number of bullets on both sides, parallel wording. |

Chevron process (in the presentation template): `data-shape="chevron"`; in Arabic add `data-flip-h`
so arrows point left (the direction of reading).

## Rules that keep them editable and clean
- No `::before/::after` for dots, lines or numbers - use real elements.
- Circles = square box + `border-radius:50%`.
- Lines = thin boxes (height 2-3 px) or single-side borders.
- Don't rotate with `transform`; choose a preset shape or flip attribute instead.
- Use the deck's CSS variables so the brand palette applies everywhere.
- Keep text short: component labels ≤ 4 words, captions ≤ 8 words.

## Extra ideas built from the same pieces
- **Gauge / % achieved**: doughnut chart with two slices (achieved + remainder in `--line` color),
  `hole_size` 70, big number in a text box centered over the hole.
- **Harvey balls / ratings**: small circles filled/outlined.
- **Pyramid / hierarchy**: stacked boxes of decreasing width (or `data-shape="trapezoid"`).
- **Matrix 2×2**: four boxes in a grid with axis labels; position items as small circles.
- **Sources & uses**: two stacked bars (`stacked_column` with one category each) side by side.
