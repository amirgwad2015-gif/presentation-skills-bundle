---
name: presentation-charts-infographics
description: Design and build charts, statistical graphics and infographics for presentations - native editable PowerPoint charts (column, bar, line, combo bar+line, waterfall/bridge, pie, doughnut, stacked, scatter) and infographic elements (KPI tiles, progress bars, process steps, timelines, funnels, comparisons) that stay editable. Handles Arabic right-to-left charts. Use this skill whenever a presentation or report needs a chart, graph, visual of numbers, financial bridge, KPI dashboard slide or infographic - including Arabic requests like رسم بياني، شارت، انفوجراف، مؤشرات أداء - and whenever turning a table of figures into a visual.
---

# Presentation Charts & Infographics

Goal: every number on a slide is shown in the form that makes its message obvious in 3 seconds,
and it stays editable in PowerPoint (native charts → right-click → Edit Data; infographics → native shapes).

This skill works with **editable-presentation-builder**: there, a chart is a `<div data-chart='{json}'>`
and an infographic is plain HTML from `assets/infographics.html`; `html2pptx.py` turns both into native
objects. Without that skill, `scripts/chart_builder.py` adds a native chart to any existing .pptx.

## 1. Start from the message, then pick the form

Write the takeaway first ("EBITDA rose 41% driven by volume"), then choose:

| Message | Form |
|---|---|
| Change over time (4+ periods) | line; column if ≤ 6 periods and you want the values read |
| Compare items / ranking | bar (horizontal), sorted descending; highlight the item that matters |
| Amount + ratio on the same periods (revenue + margin, sales + growth %) | `combo` - columns + line on secondary axis |
| Bridge from A to B (EBITDA bridge, budget → actual, cash walk, price/volume/mix) | `waterfall` |
| Composition of a total at one point | doughnut (≤ 5 parts) or single stacked bar |
| Composition over time | stacked column (absolute) or percent_stacked_column (mix) |
| Actual vs budget/target | clustered column (budget in grey/muted, actual in primary) or bar with target |
| Relationship of two variables | scatter |
| 1-4 headline numbers | KPI tiles, not a chart |
| Progress to target, utilisation, share of one thing | progress bars / big-number callout |
| Sequence of steps | numbered steps or chevrons |
| Dates / milestones | timeline |
| Before vs after, option A vs B | comparison columns |
| Detailed figures the audience must look up | table (not a chart) |

Avoid: 3D, pie with > 5 slices, two pies side by side for comparison (use stacked bars), dual axes
without the line being clearly a ratio, rainbow colors, legends when direct labels would do.

## 2. Make it read like a professional chart
- **Title on the slide, not in the chart.** The slide title states the insight; the chart has no title
  (default) unless two charts share a slide - then give each a short label above it.
- **Direct labels over axes.** Data labels on, value axis hidden (the default when labels are on).
  For dense multi-series lines, turn labels off and keep the axis + light gridlines (default).
- **Color with intent.** One series → primary color. Emphasise the one bar that matters with the accent
  (`"point_colors": {"3": "#E9C46A"}`) and leave the others in primary or muted grey.
  Budget/prior-year in grey, actual/current in primary. Negative variances in the `negative` color.
- **Brand palette.** Pass the deck's colors via `"colors"` (or rely on the palette you set in the deck).
- **Number formats (user defaults):** amounts `"#,##0"` (no decimals), percentages `"0.0%"` with values
  as fractions (0.182), large figures scaled in the unit ("مليون جنيه") rather than showing 1,250,000,000.
- **Sort** bars by value unless the categories have a natural order (time, process).
- **Units and source**: unit in the slide title or a small label; source line under the chart.
- Leave the chart at least 300×220 px; label font ≥ 11 pt.

## 3. Arabic / RTL charts
Charts inherit direction from the page (`dir="rtl"`) and are mirrored automatically: first category
on the right, value axis on the right, horizontal bars grow from right to left, legends and labels
right-to-left with the Arabic font. Give categories in natural chronological order (2022, 2023, …);
do not reverse them yourself. Waterfall decreases are labelled `(22)` so the sign reads correctly.
Axis/legend text can mix Arabic and English (EBITDA) freely.

## 4. Build it
Chart JSON spec: `references/chart-spec.md` (all types and keys). Examples:

```html
<!-- revenue + margin -->
<div style="height:360px" data-chart='{"type":"combo","categories":["2022","2023","2024","2025"],
  "series":[{"name":"الإيرادات (مليون جنيه)","values":[640,810,1060,1250]},
            {"name":"هامش EBITDA","values":[0.112,0.121,0.129,0.142],"type":"line","axis":"secondary","number_format":"0.0%","color":"#E9C46A"}]}'></div>

<!-- EBITDA bridge -->
<div style="height:340px" data-chart='{"type":"waterfall",
  "categories":["EBITDA 2024","الكميات","الأسعار","الخامات","مصروفات إدارية","EBITDA 2025"],
  "values":[137,45,30,-22,-12,178],"totals":[0,5]}'></div>
```

Infographic components (copy CSS + markup): `assets/infographics.html` - KPI tile with delta, progress
bars, numbered steps with connector, timeline, icon rows (inline SVG icons), funnel, big-number callout,
status pills, before/after comparison. `references/infographics.md` explains when to use each and the
rules that keep them editable.

Standalone (existing deck, no HTML):
```bash
python scripts/chart_builder.py deck.pptx spec.json --slide 4 --box 0.6,1.5,12.1,5.4 --rtl --font "Segoe UI"
```

## 5. Check
Render the deck (`render.py` in editable-presentation-builder) and look at every chart: labels not
overlapping, colors match the brand, no clipped legend, RTL order correct, formats right (no 12.345%).
Verify every plotted value against the source data - a wrong number in a bank deck is worse than an
ugly chart.
