#!/usr/bin/env python3
"""
html2pptx.py - Convert an HTML slide deck into a fully EDITABLE PowerPoint file.

Every <section class="slide"> in the HTML becomes one slide. The page is rendered
in headless Chromium (Playwright), each element's real position and computed style
is measured, and native PowerPoint objects are rebuilt from them:

  text (h1-h6, p, li, span, div with text)  -> editable text boxes (runs keep bold/color/size)
  div with background / border / radius     -> native shapes (rect, rounded rect, ellipse)
  data-shape="chevron|arrow|..."             -> PowerPoint preset shapes (for infographics)
  <table>                                    -> native table (merged cells, borders, RTL)
  <div data-chart='{json}'>                  -> native chart (see chart_builder.py)
  <img>                                      -> picture (object-fit: cover is cropped)
  <svg> or [data-raster]                     -> high-resolution PNG picture (icons, complex art)
  <aside class="notes">                      -> speaker notes
  dir="rtl" / direction: rtl                 -> right-to-left paragraphs, tables and charts

Usage:
  python html2pptx.py deck.html -o deck.pptx [--template brand.pptx] [--font "Segoe UI"]
                      [--preview previews_dir] [--keep-template-slides]

1 CSS px == 1 pt when the slide section is 960x540 px (16:9, 13.333 x 7.5 in).
Any section size works; everything is scaled to the output slide width.
"""
import argparse
import base64
import io
import json
import os
import re
import sys
import urllib.request

from lxml import etree
from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR, MSO_AUTO_SIZE
from pptx.oxml.ns import qn
from pptx.util import Emu, Pt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from chart_builder import add_chart  # noqa: E402

# --------------------------------------------------------------------------------------
# Browser-side extraction
# --------------------------------------------------------------------------------------
EXTRACT_JS = r"""
() => {
  const INLINE = new Set(['B','STRONG','I','EM','U','SPAN','BR','SUP','SUB','SMALL','A','MARK','CODE','S','BDI','BDO','Q','ABBR','TIME','LABEL']);
  const px = v => parseFloat(v) || 0;
  function color(c) {
    if (!c) return null;
    const m = c.match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    const p = m[1].split(/[\s,\/]+/).filter(Boolean).map(parseFloat);
    const a = p.length > 3 ? p[3] : 1;
    if (a <= 0.001) return null;
    const hex = p.slice(0,3).map(x => Math.max(0,Math.min(255,Math.round(x))).toString(16).padStart(2,'0')).join('');
    return {hex, alpha: a};
  }
  function gradient(bg) {
    if (!bg || !bg.startsWith('linear-gradient')) return null;
    const inner = bg.slice(bg.indexOf('(')+1, bg.lastIndexOf(')'));
    const parts = []; let depth=0, cur='';
    for (const ch of inner) { if (ch==='(') depth++; if (ch===')') depth--; if (ch===',' && depth===0){parts.push(cur.trim());cur='';} else cur+=ch; }
    if (cur.trim()) parts.push(cur.trim());
    let angle = 180;
    if (/deg$/.test(parts[0])) { angle = parseFloat(parts.shift()); }
    else if (parts[0].startsWith('to ')) {
      const t = parts.shift();
      const map = {'to top':0,'to right':90,'to bottom':180,'to left':270,'to top right':45,'to bottom right':135,'to bottom left':225,'to top left':315};
      angle = map[t] ?? 180;
    }
    const stops = parts.map((s, i) => {
      const cm = s.match(/rgba?\([^)]+\)/); const c = color(cm ? cm[0] : '');
      const pm = s.replace(cm ? cm[0] : '', '').match(/([\d.]+)%/);
      return {color: c, pos: pm ? parseFloat(pm[1]) : (i/(Math.max(1,parts.length-1)))*100};
    }).filter(s => s.color);
    return stops.length >= 2 ? {angle, stops} : null;
  }
  function shadow(bs) {
    if (!bs || bs === 'none') return null;
    const cm = bs.match(/rgba?\([^)]+\)/); const c = color(cm ? cm[0] : 'rgba(0,0,0,0.2)');
    const nums = bs.replace(cm ? cm[0] : '', '').trim().split(/\s+/).map(parseFloat).filter(n => !isNaN(n));
    if (/inset/.test(bs) || !c) return null;
    return {color: c, x: nums[0]||0, y: nums[1]||0, blur: nums[2]||0};
  }
  function visible(el, cs) {
    return cs.display !== 'none' && cs.visibility !== 'hidden' && parseFloat(cs.opacity) > 0.01;
  }
  function family(ff) { return (ff || '').split(',')[0].replace(/["']/g,'').trim(); }
  function runStyle(el) {
    const cs = getComputedStyle(el);
    return {
      size: px(cs.fontSize), bold: (parseInt(cs.fontWeight) || 400) >= 600,
      italic: cs.fontStyle === 'italic',
      underline: (cs.textDecorationLine || '').includes('underline'),
      strike: (cs.textDecorationLine || '').includes('line-through'),
      color: color(cs.color), font: family(cs.fontFamily),
      transform: cs.textTransform, sup: el.tagName === 'SUP', sub: el.tagName === 'SUB',
      spacing: cs.letterSpacing === 'normal' ? 0 : px(cs.letterSpacing),
      href: el.tagName === 'A' ? el.getAttribute('href') : null
    };
  }
  function applyTransform(t, tr) {
    if (tr === 'uppercase') return t.toUpperCase();
    if (tr === 'lowercase') return t.toLowerCase();
    if (tr === 'capitalize') return t.replace(/\b\w/g, c => c.toUpperCase());
    return t;
  }
  // collect runs from inline content; returns list of lines (split on <br>)
  function collectRuns(nodes, runs) {
    for (const n of nodes) {
      if (n.nodeType === 3) {
        const st = runStyle(n.parentElement);
        let t = n.textContent.replace(/[\s\n\r\t]+/g, ' ');
        t = applyTransform(t, st.transform);
        if (t.length) runs.push({text: t, style: st});
      } else if (n.nodeType === 1) {
        const cs = getComputedStyle(n);
        if (!visible(n, cs)) continue;
        if (n.tagName === 'BR') { runs.push({br: true}); continue; }
        if (n.tagName === 'UL' || n.tagName === 'OL') continue;
        collectRuns(n.childNodes, runs);
      }
    }
    return runs;
  }
  function cleanRuns(runs) {
    // collapse spaces across run boundaries & trim paragraph edges
    const out = [];
    for (const r of runs) {
      if (r.br) { out.push(r); continue; }
      const prev = out.length ? out[out.length-1] : null;
      let t = r.text;
      if ((!prev || prev.br || /\s$/.test(prev.text)) ) t = t.replace(/^\s+/, '');
      if (t.length) out.push({text: t, style: r.style});
    }
    // trim trailing space before br and at end
    for (let i = 0; i < out.length; i++) {
      if (out[i].br) continue;
      const nxt = out[i+1];
      if (!nxt || nxt.br) out[i].text = out[i].text.replace(/\s+$/, '');
    }
    return out.filter(r => r.br || r.text.length);
  }
  function isInlineOnly(el) {
    for (const n of el.childNodes) {
      if (n.nodeType === 1) {
        if (!INLINE.has(n.tagName)) return false;
        const cs = getComputedStyle(n);
        if (n.tagName !== 'BR' && !cs.display.startsWith('inline')) return false;
        if (cs.display === 'inline-block' || cs.display === 'inline-flex') return false;
        if (n.hasAttribute('data-chart') || n.hasAttribute('data-raster')) return false;
        if (!isInlineOnly(n)) return false;
      }
    }
    return true;
  }
  function hasText(el) { return (el.textContent || '').trim().length > 0; }
  function alignOf(cs) {
    const rtl = cs.direction === 'rtl';
    let a = cs.textAlign;
    if (a === 'start' || a === '-webkit-auto' || a === 'auto') a = rtl ? 'right' : 'left';
    if (a === 'end') a = rtl ? 'left' : 'right';
    if (a === '-webkit-center') a = 'center';
    if (a === '-webkit-right') a = 'right';
    if (a === '-webkit-left') a = 'left';
    return a;
  }
  function lineHeight(cs) {
    if (cs.lineHeight === 'normal') return px(cs.fontSize) * 1.2;
    return px(cs.lineHeight);
  }
  function paraProps(el) {
    const cs = getComputedStyle(el);
    return {align: alignOf(cs), rtl: cs.direction === 'rtl', lineHeight: lineHeight(cs), fontSize: px(cs.fontSize)};
  }
  function textRect(el, origin) {
    const range = document.createRange(); range.selectNodeContents(el);
    const r = range.getBoundingClientRect();
    return {x: r.left - origin.x, y: r.top - origin.y, w: r.width, h: r.height};
  }
  function boxOf(el, origin) {
    const r = el.getBoundingClientRect();
    return {x: r.left - origin.x, y: r.top - origin.y, w: r.width, h: r.height};
  }
  function borders(cs) {
    const s = {};
    for (const side of ['Top','Right','Bottom','Left']) {
      const w = px(cs['border'+side+'Width']);
      const st = cs['border'+side+'Style'];
      const c = color(cs['border'+side+'Color']);
      if (w > 0 && st !== 'none' && st !== 'hidden' && c) s[side[0].toLowerCase()] = {w, color: c, dash: st === 'dashed' ? 'dash' : (st === 'dotted' ? 'dot' : null)};
    }
    return s;
  }
  function radiusOf(cs, box) {
    let r = cs.borderTopLeftRadius || '0';
    let v = parseFloat(r) || 0;
    if (r.includes('%')) v = Math.min(box.w, box.h) * v / 100;
    return v;
  }
  function listParagraphs(list, level, paras) {
    const ordered = list.tagName === 'OL';
    let idx = parseInt(list.getAttribute('start') || '1');
    for (const li of list.children) {
      if (li.tagName !== 'LI') continue;
      const cs = getComputedStyle(li);
      if (!visible(li, cs)) continue;
      const inline = [];
      const nested = [];
      for (const n of li.childNodes) {
        if (n.nodeType === 1 && (n.tagName === 'UL' || n.tagName === 'OL')) nested.push(n);
        else inline.push(n);
      }
      const runs = cleanRuns(collectRuns(inline, []));
      const lst = cs.listStyleType;
      let bullet = null;
      if (lst && lst !== 'none') bullet = ordered ? {type: 'num', n: idx, style: lst} : {type: 'char', char: lst === 'circle' ? '◦' : (lst === 'square' ? '▪' : '•')};
      const custom = li.getAttribute('data-bullet');
      if (custom) bullet = {type: 'char', char: custom};
      const bc = color(getComputedStyle(li, '::marker').color) || color(cs.color);
      const pp = paraProps(li);
      if (runs.length) paras.push(Object.assign(pp, {runs, bullet, bulletColor: bc, level,
        indent: px(li.parentElement === list ? getComputedStyle(list)[pp.rtl ? 'paddingRight' : 'paddingLeft'] : 0),
        spaceBefore: px(cs.marginTop), spaceAfter: px(cs.marginBottom)}));
      idx++;
      for (const nl of nested) listParagraphs(nl, level + 1, paras);
    }
    return paras;
  }
  function isTextList(el) {
    if (el.tagName !== 'UL' && el.tagName !== 'OL') return false;
    for (const li of el.querySelectorAll('li')) {
      const cs = getComputedStyle(li);
      if (color(cs.backgroundColor) || Object.keys(borders(cs)).length) return false;
      if (cs.display.includes('flex') || cs.display.includes('grid')) return false;
      for (const n of li.childNodes) {
        if (n.nodeType === 1 && !(n.tagName === 'UL' || n.tagName === 'OL') && !isInlineOnly(n) ) return false;
        if (n.nodeType === 1 && !(n.tagName === 'UL' || n.tagName === 'OL') && !INLINE.has(n.tagName)) return false;
      }
    }
    return true;
  }

  const slides = [];
  const sections = [...document.querySelectorAll('section.slide, .slide')].filter(s => !s.parentElement.closest('.slide'));
  sections.forEach((sec, si) => {
    const sr = sec.getBoundingClientRect();
    const origin = {x: sr.left, y: sr.top};
    const scs = getComputedStyle(sec);
    const slide = {index: si, w: sr.width, h: sr.height, rtl: scs.direction === 'rtl',
      bg: color(scs.backgroundColor), bgGradient: gradient(scs.backgroundImage),
      bgImage: (scs.backgroundImage.match(/url\(["']?([^"')]+)["']?\)/) || [])[1] || null,
      items: [], notes: null};
    let order = 0;

    function emitShape(el, cs, box, textObj) {
      const fill = color(cs.backgroundColor);
      const grad = gradient(cs.backgroundImage);
      const bimg = (cs.backgroundImage.match(/url\(["']?([^"')]+)["']?\)/) || [])[1] || null;
      const b = borders(cs);
      const preset = el.getAttribute('data-shape');
      const hasBorder = Object.keys(b).length > 0;
      if (!fill && !grad && !hasBorder && !preset && !bimg && !textObj) return false;
      const sides = Object.values(b);
      const uniform = sides.length === 4 && sides.every(s => s.w === sides[0].w && s.color.hex === sides[0].color.hex);
      const op = parseFloat(cs.opacity);
      slide.items.push({kind: 'shape', z: order++, box, fill, grad, bgImage: bimg,
        bgSize: cs.backgroundSize, opacity: op,
        outline: uniform ? sides[0] : null, sideBorders: uniform ? null : b,
        radius: radiusOf(cs, box), preset, rotation: 0,
        shadow: shadow(cs.boxShadow), text: textObj || null,
        name: el.getAttribute('data-name') || el.id || null,
        flipH: el.hasAttribute('data-flip-h'), flipV: el.hasAttribute('data-flip-v'),
        shapeAdj: el.getAttribute('data-adj')});
      return true;
    }

    function textObject(el, cs, box, paras) {
      // insets = padding + border, anchor from text position
      const tr = textRect(el, origin);
      const insets = {l: px(cs.paddingLeft) + px(cs.borderLeftWidth), r: px(cs.paddingRight) + px(cs.borderRightWidth),
                      t: px(cs.paddingTop) + px(cs.borderTopWidth), b: px(cs.paddingBottom) + px(cs.borderBottomWidth)};
      const innerTop = box.y + insets.t, innerBottom = box.y + box.h - insets.b;
      const gapTop = tr.y - innerTop, gapBottom = innerBottom - (tr.y + tr.h);
      let anchor = 't';
      if (Math.abs(gapTop - gapBottom) < 3) anchor = 'ctr';
      else if (gapBottom < gapTop - 3) anchor = 'b';
      const ws = cs.whiteSpace;
      // text centred by flexbox/grid (not text-align) -> centre it in PowerPoint too
      const innerL = box.x + insets.l, innerR = box.x + box.w - insets.r;
      const gapL = tr.x - innerL, gapR = innerR - (tr.x + tr.w);
      if (paras.length === 1 && gapL > 3 && Math.abs(gapL - gapR) < 3) paras[0].align = 'center';
      const lh = paras.length ? (paras[0].lineHeight || 20) : 20;
      const hasBr = paras.some(p => (p.runs || []).some(r => r.br));
      const singleLine = paras.length === 1 && !hasBr && tr.h < lh * 1.5;
      return {paras, insets, anchor, textRect: tr, wrap: !(ws === 'nowrap' || ws === 'pre') && !singleLine,
              singleLine, rtl: cs.direction === 'rtl'};
    }

    function walk(el) {
      const cs = getComputedStyle(el);
      if (!visible(el, cs)) return;
      if (el.tagName === 'ASIDE' && el.classList.contains('notes')) { slide.notes = el.innerText.trim(); return; }
      if (['SCRIPT','STYLE','TEMPLATE','NOSCRIPT'].includes(el.tagName)) return;
      const box = boxOf(el, origin);
      if (box.w <= 0.5 || box.h <= 0.5) {
        // zero-size wrappers can still contain positioned children
        for (const c of el.children) walk(c);
        return;
      }
      if (el.hasAttribute('data-chart')) {
        let spec = {};
        try { spec = JSON.parse(el.getAttribute('data-chart')); } catch (e) { spec = {error: String(e)}; }
        slide.items.push({kind: 'chart', z: order++, box, spec, rtl: cs.direction === 'rtl', font: family(cs.fontFamily), color: color(cs.color)});
        return;
      }
      if (el.tagName === 'svg' || el.tagName === 'SVG' || el.tagName === 'CANVAS' || el.hasAttribute('data-raster')) {
        const id = 'r' + si + '_' + order;
        el.setAttribute('data-raster-id', id);
        slide.items.push({kind: 'raster', z: order++, box, id});
        return;
      }
      if (el.tagName === 'IMG') {
        slide.items.push({kind: 'image', z: order++, box, src: el.currentSrc || el.src, fit: cs.objectFit,
                          nat: {w: el.naturalWidth, h: el.naturalHeight}, radius: radiusOf(cs, box)});
        return;
      }
      if (el.tagName === 'TABLE') {
        const rows = [];
        const tcs = getComputedStyle(el);
        for (const tr of el.rows) {
          const cells = [];
          for (const td of tr.cells) {
            const ccs = getComputedStyle(td);
            const cb = boxOf(td, origin);
            let cbg = color(ccs.backgroundColor) || color(getComputedStyle(tr).backgroundColor);
            if (!cbg && tr.parentElement) cbg = color(getComputedStyle(tr.parentElement).backgroundColor);
            const runs = cleanRuns(collectRuns(td.childNodes, []));
            cells.push({box: cb, runs, bg: cbg, borders: borders(ccs), align: alignOf(ccs), valign: ccs.verticalAlign,
                        rtl: ccs.direction === 'rtl', lineHeight: lineHeight(ccs),
                        pad: {l: px(ccs.paddingLeft), r: px(ccs.paddingRight), t: px(ccs.paddingTop), b: px(ccs.paddingBottom)},
                        colspan: td.colSpan, rowspan: td.rowSpan});
          }
          rows.push({box: boxOf(tr, origin), cells});
        }
        slide.items.push({kind: 'table', z: order++, box, rows, rtl: tcs.direction === 'rtl', bg: color(tcs.backgroundColor)});
        return;
      }
      // text lists
      if (isTextList(el)) {
        const paras = listParagraphs(el, 0, []);
        if (paras.length) {
          const tobj = textObject(el, cs, box, paras);
          if (!emitShape(el, cs, box, tobj)) {}
        }
        return;
      }
      // text leaf: all children inline and some text
      if (hasText(el) && isInlineOnly(el)) {
        const runs = cleanRuns(collectRuns(el.childNodes, []));
        if (runs.length) {
          const pp = paraProps(el);
          const para = Object.assign(pp, {runs, bullet: null, level: 0, spaceBefore: 0, spaceAfter: 0});
          const tobj = textObject(el, cs, box, [para]);
          emitShape(el, cs, box, tobj);
          return;
        }
      }
      // container: shape for its own decoration, then children
      emitShape(el, cs, box, null);
      for (const n of el.childNodes) {
        if (n.nodeType === 3 && n.textContent.trim()) {
          // stray text inside a block container -> its own text box
          const range = document.createRange(); range.selectNodeContents(n);
          const r = range.getBoundingClientRect();
          const tb = {x: r.left - origin.x, y: r.top - origin.y, w: r.width, h: r.height};
          const st = runStyle(el);
          const pp = paraProps(el);
          const t = applyTransform(n.textContent.replace(/\s+/g, ' ').trim(), st.transform);
          slide.items.push({kind: 'shape', z: order++, box: tb, fill: null, outline: null, radius: 0,
            text: {paras: [Object.assign(pp, {runs: [{text: t, style: st}], bullet: null, level: 0, spaceBefore: 0, spaceAfter: 0})],
                   insets: {l:0,r:0,t:0,b:0}, anchor: 't', textRect: tb, wrap: false, rtl: pp.rtl, loose: true}});
        } else if (n.nodeType === 1) {
          walk(n);
        }
      }
    }
    for (const c of sec.children) walk(c);
    slides.push(slide);
  });
  return slides;
}
"""

ARABIC_RE = re.compile("[؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿]")
RANGE_RE = re.compile(r"(\d[\d,.]*\s?%?)\s*[-–—]\s*(\d[\d,.]*\s?%?)")


def fix_rtl_ranges(text):
    """In RTL text, '10% - 15%' must use spaces + en dash so the bidi algorithm
    lays it out right-to-left (10% on the right). '10%-15%' would stay LTR."""
    return RANGE_RE.sub(lambda m: f"{m.group(1).strip()} – {m.group(2).strip()}", text)


# --------------------------------------------------------------------------------------
# PowerPoint building helpers
# --------------------------------------------------------------------------------------
class Ctx:
    def __init__(self, prs, scale, font_override, html_dir, default_font):
        self.prs = prs
        self.s = scale  # EMU per CSS px
        self.font_override = font_override
        self.html_dir = html_dir
        self.default_font = default_font

    def e(self, v):
        return Emu(int(round(v * self.s)))

    def pt(self, px_val):
        return Pt(px_val * self.s / 12700.0)


def _set_alpha(fill_fore_color_parent_xml, alpha):
    if alpha is None or alpha >= 0.999:
        return
    clr = fill_fore_color_parent_xml
    a = etree.SubElement(clr, qn("a:alpha"))
    a.set("val", str(int(alpha * 100000)))


def _solid(fill, col, extra_alpha=1.0):
    fill.solid()
    fill.fore_color.rgb = RGBColor.from_string(col["hex"].upper())
    alpha = col.get("alpha", 1) * extra_alpha
    if alpha < 0.999:
        srgb = fill._xPr.find(".//" + qn("a:srgbClr")) if hasattr(fill, "_xPr") else None
        if srgb is None:
            # python-pptx FillFormat keeps element in _xPr
            srgb = fill._xPr.find(qn("a:solidFill")).find(qn("a:srgbClr"))
        _set_alpha(srgb, alpha)


def _gradient(fill, grad):
    fill.gradient()
    # CSS angle: 0 = to top, 90 = to right. DrawingML lin ang: 0 = left->right, clockwise.
    ang = (grad["angle"] - 90) % 360
    fill.gradient_angle = 0
    gs_lst = fill._xPr.find(".//" + qn("a:gsLst"))
    for gs in list(gs_lst):
        gs_lst.remove(gs)
    for st in grad["stops"]:
        gs = etree.SubElement(gs_lst, qn("a:gs"))
        gs.set("pos", str(int(max(0, min(100, st["pos"])) * 1000)))
        c = etree.SubElement(gs, qn("a:srgbClr"))
        c.set("val", st["color"]["hex"].upper())
        if st["color"]["alpha"] < 0.999:
            _set_alpha(c, st["color"]["alpha"])
    lin = fill._xPr.find(".//" + qn("a:lin"))
    if lin is None:
        gradFill = fill._xPr.find(qn("a:gradFill"))
        lin = etree.SubElement(gradFill, qn("a:lin"))
    lin.set("ang", str(int(ang * 60000)))
    lin.set("scaled", "0")


def _add_shadow(shape, sh, ctx):
    spPr = shape._element.spPr
    eff = etree.SubElement(spPr, qn("a:effectLst"))
    o = etree.SubElement(eff, qn("a:outerShdw"))
    import math
    dist = math.hypot(sh["x"], sh["y"])
    ang = (math.degrees(math.atan2(sh["y"], sh["x"])) % 360) if dist else 90
    o.set("blurRad", str(int(sh["blur"] * ctx.s)))
    o.set("dist", str(int(dist * ctx.s)))
    o.set("dir", str(int(ang * 60000)))
    o.set("algn", "ctr")
    o.set("rotWithShape", "0")
    c = etree.SubElement(o, qn("a:srgbClr"))
    c.set("val", sh["color"]["hex"].upper())
    _set_alpha(c, sh["color"]["alpha"])


def _line_dash(line, dash):
    if dash:
        from pptx.enum.dml import MSO_LINE_DASH_STYLE
        line.dash_style = MSO_LINE_DASH_STYLE.DASH if dash == "dash" else MSO_LINE_DASH_STYLE.ROUND_DOT


PRESETS = {
    "rect": MSO_SHAPE.RECTANGLE, "rounded": MSO_SHAPE.ROUNDED_RECTANGLE, "ellipse": MSO_SHAPE.OVAL,
    "circle": MSO_SHAPE.OVAL, "chevron": MSO_SHAPE.CHEVRON, "pentagon": MSO_SHAPE.PENTAGON,
    "homeplate": MSO_SHAPE.PENTAGON, "arrow-right": MSO_SHAPE.RIGHT_ARROW, "arrow-left": MSO_SHAPE.LEFT_ARROW,
    "arrow-up": MSO_SHAPE.UP_ARROW, "arrow-down": MSO_SHAPE.DOWN_ARROW, "triangle": MSO_SHAPE.ISOSCELES_TRIANGLE,
    "right-triangle": MSO_SHAPE.RIGHT_TRIANGLE, "diamond": MSO_SHAPE.DIAMOND, "hexagon": MSO_SHAPE.HEXAGON,
    "octagon": MSO_SHAPE.OCTAGON, "parallelogram": MSO_SHAPE.PARALLELOGRAM, "trapezoid": MSO_SHAPE.TRAPEZOID,
    "star": MSO_SHAPE.STAR_5_POINT, "donut": MSO_SHAPE.DONUT, "block-arc": MSO_SHAPE.BLOCK_ARC,
    "callout": MSO_SHAPE.RECTANGULAR_CALLOUT, "round-callout": MSO_SHAPE.ROUNDED_RECTANGULAR_CALLOUT,
    "snip": MSO_SHAPE.SNIP_1_RECTANGLE, "round-1": MSO_SHAPE.ROUND_1_RECTANGLE, "round-2-diag": MSO_SHAPE.ROUND_2_DIAG_RECTANGLE,
    "plus": MSO_SHAPE.CROSS, "flowchart-process": MSO_SHAPE.FLOWCHART_PROCESS, "cloud": MSO_SHAPE.CLOUD,
    "notched-arrow-right": MSO_SHAPE.NOTCHED_RIGHT_ARROW, "chord": MSO_SHAPE.CHORD, "pie": MSO_SHAPE.PIE,
    "wave": MSO_SHAPE.WAVE, "frame": MSO_SHAPE.FRAME, "teardrop": MSO_SHAPE.TEAR,
}


def _is_arabic(t):
    return bool(ARABIC_RE.search(t or ""))


def _fill_text(tf, tobj, ctx, slide_rtl):
    tf.word_wrap = tobj.get("wrap", True)
    tf.auto_size = MSO_AUTO_SIZE.NONE
    ins = tobj["insets"]
    tf.margin_left, tf.margin_right = ctx.e(ins["l"]), ctx.e(ins["r"])
    tf.margin_top, tf.margin_bottom = ctx.e(ins["t"]), ctx.e(ins["b"])
    tf.vertical_anchor = {"t": MSO_ANCHOR.TOP, "ctr": MSO_ANCHOR.MIDDLE, "b": MSO_ANCHOR.BOTTOM}[tobj.get("anchor", "t")]
    first = True
    for para in tobj["paras"]:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        rtl = para.get("rtl", slide_rtl)
        p.alignment = {"left": PP_ALIGN.LEFT, "right": PP_ALIGN.RIGHT, "center": PP_ALIGN.CENTER,
                       "justify": PP_ALIGN.JUSTIFY}.get(para.get("align"), PP_ALIGN.RIGHT if rtl else PP_ALIGN.LEFT)
        pPr = p._p.get_or_add_pPr()
        if rtl:
            pPr.set("rtl", "1")
        # exact line height as in the browser
        lh = para.get("lineHeight")
        if lh:
            p.line_spacing = ctx.pt(lh)
        if para.get("spaceBefore"):
            p.space_before = ctx.pt(para["spaceBefore"])
        if para.get("spaceAfter"):
            p.space_after = ctx.pt(para["spaceAfter"])
        b = para.get("bullet")
        if b:
            fs = para.get("fontSize", 16)
            indent_px = max(para.get("indent") or 0, fs * 1.1)
            lvl = para.get("level", 0)
            mar = indent_px * (lvl + 1)
            pPr.set("marL", str(int(mar * ctx.s)))
            pPr.set("indent", str(int(-indent_px * ctx.s)))
            if lvl:
                pPr.set("lvl", str(min(lvl, 8)))
            if para.get("bulletColor"):
                bc = etree.SubElement(pPr, qn("a:buClr"))
                etree.SubElement(bc, qn("a:srgbClr")).set("val", para["bulletColor"]["hex"].upper())
            if b["type"] == "char":
                etree.SubElement(pPr, qn("a:buFont")).set("typeface", "Arial")
                etree.SubElement(pPr, qn("a:buChar")).set("char", b["char"])
            else:
                scheme = "arabicPeriod"
                st = b.get("style", "decimal")
                if st in ("arabic-indic",):
                    scheme = "arabicDbPeriod" if False else "arabic1Minus"
                elif st == "lower-alpha" or st == "lower-latin":
                    scheme = "alphaLcPeriod"
                elif st == "upper-alpha" or st == "upper-latin":
                    scheme = "alphaUcPeriod"
                an = etree.SubElement(pPr, qn("a:buAutoNum"))
                an.set("type", scheme)
                if b.get("n", 1) != 1:
                    an.set("startAt", str(b["n"]))
        else:
            etree.SubElement(pPr, qn("a:buNone"))
        for r in para["runs"]:
            if r.get("br"):
                p.add_line_break()
                continue
            text = r["text"]
            if rtl:
                text = fix_rtl_ranges(text)
            run = p.add_run()
            run.text = text
            st = r["style"]
            f = run.font
            f.size = ctx.pt(st["size"])
            f.bold = bool(st["bold"])
            f.italic = bool(st["italic"])
            if st.get("underline"):
                f.underline = True
            if st.get("color"):
                f.color.rgb = RGBColor.from_string(st["color"]["hex"].upper())
                if st["color"]["alpha"] < 0.999:
                    _set_alpha(run._r.find(".//" + qn("a:srgbClr")), st["color"]["alpha"])
            font = ctx.font_override or st.get("font") or ctx.default_font
            if font.lower() in ("sans-serif", "serif", "system-ui", "-apple-system", "inherit", ""):
                font = ctx.default_font
            f.name = font
            rPr = run._r.get_or_add_rPr()
            for tag in ("a:ea", "a:cs"):
                el = rPr.find(qn(tag))
                if el is None:
                    el = etree.SubElement(rPr, qn(tag))
                el.set("typeface", font)
            # element order in rPr: ln, fill, effect, highlight, uLnTx.., latin, ea, cs, sym, hlinkClick
            latin = rPr.find(qn("a:latin"))
            if latin is not None:
                rPr.remove(latin)
                rPr.find(qn("a:ea")).addprevious(latin)
            if _is_arabic(text):
                rPr.set("lang", "ar-EG")
                rPr.set("altLang", "en-US")
            else:
                rPr.set("lang", "en-US")
            if st.get("strike"):
                rPr.set("strike", "sngStrike")
            if st.get("sup"):
                rPr.set("baseline", "30000")
            if st.get("sub"):
                rPr.set("baseline", "-25000")
            if st.get("spacing"):
                rPr.set("spc", str(int(st["spacing"] * ctx.s / 12700 * 100)))
            if st.get("href") and st["href"].startswith("http"):
                run.hyperlink.address = st["href"]


def _add_shape_item(slide, it, ctx, slide_rtl):
    box = it["box"]
    text = it.get("text")
    fill = it.get("fill")
    grad = it.get("grad")
    outline = it.get("outline")
    preset = it.get("preset")
    radius = it.get("radius") or 0
    x, y, w, h = box["x"], box["y"], box["w"], box["h"]

    # a plain text box (no decoration): size it from the element box
    decorated = fill or grad or outline or preset or it.get("bgImage") or it.get("shadow")
    if it.get("bgImage"):
        _add_picture(slide, {"box": box, "src": it["bgImage"], "fit": "cover" if "cover" in (it.get("bgSize") or "") else "fill",
                             "nat": None, "radius": radius}, ctx)
        decorated = fill or grad or outline or preset

    if not decorated and text:
        if text.get("singleLine"):
            # PowerPoint fonts run a little wider than Chromium's: give one-line boxes slack
            # on the side the text grows towards, and never wrap them
            extra = max(8.0, w * 0.12)
            align = text["paras"][0].get("align")
            if align == "center":
                x -= extra / 2
            elif align == "right":
                x -= extra
            w += extra
        tb = slide.shapes.add_textbox(ctx.e(x), ctx.e(y), ctx.e(w), ctx.e(h))
        _fill_text(tb.text_frame, text, ctx, slide_rtl)
        if it.get("name"):
            tb.name = it["name"]
        return tb
    if not decorated and not text:
        # only side borders -> lines
        _side_lines(slide, it, ctx)
        return None

    if preset:
        shp_type = PRESETS.get(preset, MSO_SHAPE.RECTANGLE)
    elif radius >= min(w, h) / 2 - 0.5 and abs(w - h) < 1.5:
        shp_type = MSO_SHAPE.OVAL
    elif radius > 0.5:
        shp_type = MSO_SHAPE.ROUNDED_RECTANGLE
    else:
        shp_type = MSO_SHAPE.RECTANGLE
    shp = slide.shapes.add_shape(shp_type, ctx.e(x), ctx.e(y), ctx.e(w), ctx.e(h))
    if shp_type == MSO_SHAPE.ROUNDED_RECTANGLE and not preset:
        shp.adjustments[0] = min(0.5, radius / max(1.0, min(w, h)))
    if it.get("shapeAdj"):
        for i, v in enumerate(str(it["shapeAdj"]).split(",")):
            try:
                shp.adjustments[i] = float(v)
            except Exception:
                pass
    if it.get("flipH"):
        shp._element.spPr.find(qn("a:xfrm")).set("flipH", "1")
    if it.get("flipV"):
        shp._element.spPr.find(qn("a:xfrm")).set("flipV", "1")
    op = it.get("opacity", 1) or 1
    if grad:
        _gradient(shp.fill, grad)
    elif fill:
        _solid(shp.fill, fill, op)
    else:
        shp.fill.background()
    if outline:
        shp.line.color.rgb = RGBColor.from_string(outline["color"]["hex"].upper())
        shp.line.width = ctx.pt(outline["w"])
        _line_dash(shp.line, outline.get("dash"))
    else:
        shp.line.fill.background()
    if it.get("shadow"):
        _add_shadow(shp, it["shadow"], ctx)
    # remove the theme style so text is not white/centered by default
    style = shp._element.find(qn("p:style"))
    if style is not None:
        shp._element.remove(style)
    if text and it.get("flipV"):
        # a vertically flipped shape would turn its text upside down -> separate text box on top
        shp.text_frame.text = ""
        tb = slide.shapes.add_textbox(ctx.e(x), ctx.e(y), ctx.e(w), ctx.e(h))
        _fill_text(tb.text_frame, text, ctx, slide_rtl)
    elif text:
        _fill_text(shp.text_frame, text, ctx, slide_rtl)
    else:
        shp.text_frame.text = ""
    if it.get("name"):
        shp.name = it["name"]
    if it.get("sideBorders"):
        _side_lines(slide, it, ctx)
    return shp


def _side_lines(slide, it, ctx):
    b = it.get("sideBorders") or {}
    box = it["box"]
    x, y, w, h = box["x"], box["y"], box["w"], box["h"]
    for side, spec in b.items():
        bw = spec["w"]
        if side == "t":
            coords = (x, y + bw / 2, x + w, y + bw / 2)
        elif side == "b":
            coords = (x, y + h - bw / 2, x + w, y + h - bw / 2)
        elif side == "l":
            coords = (x + bw / 2, y, x + bw / 2, y + h)
        else:
            coords = (x + w - bw / 2, y, x + w - bw / 2, y + h)
        ln = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, *[ctx.e(c) for c in coords])
        ln.line.color.rgb = RGBColor.from_string(spec["color"]["hex"].upper())
        ln.line.width = ctx.pt(bw)
        _line_dash(ln.line, spec.get("dash"))


def _load_image_bytes(src, html_dir):
    if src.startswith("data:"):
        header, data = src.split(",", 1)
        return base64.b64decode(data) if ";base64" in header else urllib.request.unquote(data).encode()
    if src.startswith("file://"):
        path = urllib.request.url2pathname(src[7:])
        return open(path, "rb").read()
    if src.startswith("http"):
        with urllib.request.urlopen(src, timeout=20) as r:
            return r.read()
    return open(os.path.join(html_dir, src), "rb").read()


def _add_picture(slide, it, ctx, data=None):
    box = it["box"]
    try:
        data = data or _load_image_bytes(it["src"], ctx.html_dir)
    except Exception as ex:
        print(f"  ! image not loaded ({it.get('src', '')[:80]}): {ex}")
        return None
    img = Image.open(io.BytesIO(data))
    if img.format not in ("PNG", "JPEG", "GIF", "BMP", "TIFF"):
        buf = io.BytesIO()
        img.convert("RGBA").save(buf, "PNG")
        data = buf.getvalue()
    pic = slide.shapes.add_picture(io.BytesIO(data), ctx.e(box["x"]), ctx.e(box["y"]), ctx.e(box["w"]), ctx.e(box["h"]))
    if it.get("fit") == "cover":
        iw, ih = img.size
        br = box["w"] / max(box["h"], 1e-6)
        ir = iw / max(ih, 1)
        if ir > br:  # image wider -> crop sides
            keep = br / ir
            pic.crop_left = pic.crop_right = (1 - keep) / 2
        elif ir < br:
            keep = ir / br
            pic.crop_top = pic.crop_bottom = (1 - keep) / 2
    elif it.get("fit") == "contain":
        iw, ih = img.size
        s = min(box["w"] / iw, box["h"] / ih)
        nw, nh = iw * s, ih * s
        pic.left = ctx.e(box["x"] + (box["w"] - nw) / 2)
        pic.top = ctx.e(box["y"] + (box["h"] - nh) / 2)
        pic.width, pic.height = ctx.e(nw), ctx.e(nh)
    r = it.get("radius") or 0
    if r > 0.5:
        geom = pic._element.spPr.find(qn("a:prstGeom"))
        if geom is not None:
            w, h = box["w"], box["h"]
            if r >= min(w, h) / 2 - 0.5 and abs(w - h) < 1.5:
                geom.set("prst", "ellipse")
            else:
                geom.set("prst", "roundRect")
                av = geom.find(qn("a:avLst"))
                gd = etree.SubElement(av, qn("a:gd"))
                gd.set("name", "adj")
                gd.set("fmla", f"val {int(min(50000, r / min(w, h) * 100000))}")
    return pic


def _cell_border(cell, side, spec, ctx):
    tcPr = cell._tc.get_or_add_tcPr()
    tag = {"l": "a:lnL", "r": "a:lnR", "t": "a:lnT", "b": "a:lnB"}[side]
    old = tcPr.find(qn(tag))
    if old is not None:
        tcPr.remove(old)
    ln = etree.Element(qn(tag))
    if spec:
        ln.set("w", str(int(spec["w"] * ctx.s)))
        sf = etree.SubElement(ln, qn("a:solidFill"))
        etree.SubElement(sf, qn("a:srgbClr")).set("val", spec["color"]["hex"].upper())
    else:
        ln.set("w", "0")
        etree.SubElement(ln, qn("a:noFill"))
    # schema order inside tcPr: lnL, lnR, lnT, lnB, ... fill
    order = ["a:lnL", "a:lnR", "a:lnT", "a:lnB"]
    idx = order.index(tag)
    inserted = False
    for later in order[idx + 1:]:
        ref = tcPr.find(qn(later))
        if ref is not None:
            ref.addprevious(ln)
            inserted = True
            break
    if not inserted:
        first_fill = None
        for child in tcPr:
            if child.tag in (qn("a:solidFill"), qn("a:noFill"), qn("a:gradFill")):
                first_fill = child
                break
        if first_fill is not None:
            first_fill.addprevious(ln)
        else:
            tcPr.append(ln)


def _add_table(slide, it, ctx, slide_rtl):
    rows = it["rows"]
    rtl = it.get("rtl", slide_rtl)
    cells_all = [c for r in rows for c in r["cells"]]
    if not cells_all:
        return
    tol = 1.0

    def edges(vals):
        out = []
        for v in sorted(vals):
            if not out or abs(v - out[-1]) > tol:
                out.append(v)
        return out

    xs = edges([c["box"]["x"] for c in cells_all] + [c["box"]["x"] + c["box"]["w"] for c in cells_all])
    ys = edges([c["box"]["y"] for c in cells_all] + [c["box"]["y"] + c["box"]["h"] for c in cells_all])

    def idx(edges_, v):
        return min(range(len(edges_)), key=lambda i: abs(edges_[i] - v))

    ncols, nrows = len(xs) - 1, len(ys) - 1
    x0, y0 = xs[0], ys[0]
    gf = slide.shapes.add_table(nrows, ncols, ctx.e(x0), ctx.e(y0), ctx.e(xs[-1] - x0), ctx.e(ys[-1] - y0))
    tbl = gf.table
    tblPr = tbl._tbl.tblPr
    for attr in ("firstRow", "bandRow", "firstCol", "lastRow", "lastCol", "bandCol"):
        tblPr.set(attr, "0")
    if rtl:
        tblPr.set("rtl", "1")
    sid = tblPr.find(qn("a:tableStyleId"))
    if sid is None:
        sid = etree.SubElement(tblPr, qn("a:tableStyleId"))
    sid.text = "{2D5ABB26-0587-4C30-8999-92F81FD0307C}"  # "No Style, No Grid"

    widths = [xs[i + 1] - xs[i] for i in range(ncols)]
    if rtl:
        widths = widths[::-1]  # grid column 0 is the right-most column in an RTL table
    for i, wv in enumerate(widths):
        tbl.columns[i].width = ctx.e(wv)
    for j in range(nrows):
        tbl.rows[j].height = ctx.e(ys[j + 1] - ys[j])

    def gcol(xleft, xright):
        c0, c1 = idx(xs, xleft), idx(xs, xright) - 1
        if rtl:
            return ncols - 1 - c1, ncols - 1 - c0
        return c0, c1

    for c in cells_all:
        b = c["box"]
        r0, r1 = idx(ys, b["y"]), idx(ys, b["y"] + b["h"]) - 1
        c0, c1 = gcol(b["x"], b["x"] + b["w"])
        if r1 < r0 or c1 < c0:
            continue
        cell = tbl.cell(r0, c0)
        if r1 > r0 or c1 > c0:
            try:
                cell.merge(tbl.cell(r1, c1))
            except Exception as ex:
                print("  ! merge failed:", ex)
        if c.get("bg"):
            _solid(cell.fill, c["bg"])
        else:
            cell.fill.background()
        pad = c["pad"]
        cell.margin_left, cell.margin_right = ctx.e(pad["l"]), ctx.e(pad["r"])
        cell.margin_top, cell.margin_bottom = ctx.e(pad["t"]), ctx.e(pad["b"])
        va = c.get("valign", "middle")
        cell.vertical_anchor = MSO_ANCHOR.TOP if va == "top" else (MSO_ANCHOR.BOTTOM if va == "bottom" else MSO_ANCHOR.MIDDLE)
        tobj = {"paras": [{"runs": c["runs"], "align": c["align"], "rtl": c.get("rtl", rtl),
                           "lineHeight": c.get("lineHeight"), "bullet": None}],
                "insets": pad, "anchor": "t", "wrap": True}
        tf = cell.text_frame
        # _fill_text sets frame-level props that cells don't have; do paragraphs only
        _fill_cell_text(tf, tobj, ctx, rtl)
        # borders follow the visual side (CSS left = left on screen)
        bd = c.get("borders", {})
        for side in ("l", "r", "t", "b"):
            _cell_border(cell, side, bd.get(side), ctx)


def _fill_cell_text(tf, tobj, ctx, rtl):
    _fill_text_paragraphs_only(tf, tobj["paras"], ctx, rtl)


def _fill_text_paragraphs_only(tf, paras, ctx, rtl):
    first = True
    for para in paras:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        prtl = para.get("rtl", rtl)
        p.alignment = {"left": PP_ALIGN.LEFT, "right": PP_ALIGN.RIGHT, "center": PP_ALIGN.CENTER,
                       "justify": PP_ALIGN.JUSTIFY}.get(para.get("align"), PP_ALIGN.RIGHT if prtl else PP_ALIGN.LEFT)
        pPr = p._p.get_or_add_pPr()
        if prtl:
            pPr.set("rtl", "1")
        if para.get("lineHeight"):
            p.line_spacing = ctx.pt(para["lineHeight"])
        etree.SubElement(pPr, qn("a:buNone"))
        for r in para["runs"]:
            if r.get("br"):
                p.add_line_break()
                continue
            _add_run(p, r, ctx, prtl)


def _add_run(p, r, ctx, rtl):
    text = fix_rtl_ranges(r["text"]) if rtl else r["text"]
    run = p.add_run()
    run.text = text
    st = r["style"]
    f = run.font
    f.size = ctx.pt(st["size"])
    f.bold = bool(st["bold"])
    f.italic = bool(st["italic"])
    if st.get("color"):
        f.color.rgb = RGBColor.from_string(st["color"]["hex"].upper())
    font = ctx.font_override or st.get("font") or ctx.default_font
    if font.lower() in ("sans-serif", "serif", "system-ui", "inherit", ""):
        font = ctx.default_font
    f.name = font
    rPr = run._r.get_or_add_rPr()
    for tag in ("a:ea", "a:cs"):
        el = etree.SubElement(rPr, qn(tag))
        el.set("typeface", font)
    rPr.set("lang", "ar-EG" if _is_arabic(text) else "en-US")


# --------------------------------------------------------------------------------------
# main conversion
# --------------------------------------------------------------------------------------
def _blank_layout(prs):
    for l in prs.slide_layouts:
        if l.name and l.name.strip().lower() in ("blank", "فارغ"):
            return l
    return min(prs.slide_layouts, key=lambda l: len(l.placeholders))


def _remove_all_slides(prs):
    sldIdLst = prs.slides._sldIdLst
    for sldId in list(sldIdLst):
        rId = sldId.get(qn("r:id"))
        prs.part.drop_rel(rId)
        sldIdLst.remove(sldId)


def convert(html_path, out_path, template=None, font=None, preview_dir=None, keep_template_slides=False,
            default_font="Segoe UI", device_scale=3):
    from playwright.sync_api import sync_playwright
    html_path = os.path.abspath(html_path)
    html_dir = os.path.dirname(html_path)
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page(viewport={"width": 1400, "height": 900}, device_scale_factor=device_scale)
        page.goto("file://" + html_path)
        page.wait_for_load_state("networkidle")
        try:
            page.evaluate("document.fonts.ready")
        except Exception:
            pass
        # neutralise viewer-only scaling so measurements are 1:1
        page.add_style_tag(content=".slide{transform:none !important; zoom:1 !important;}")
        slides = page.evaluate(EXTRACT_JS)
        if not slides:
            raise SystemExit("No <section class=\"slide\"> elements found.")
        # rasterise svg / data-raster elements
        rasters = {}
        for s in slides:
            for it in s["items"]:
                if it["kind"] == "raster":
                    loc = page.locator(f'[data-raster-id="{it["id"]}"]')
                    rasters[it["id"]] = loc.screenshot(omit_background=True, animations="disabled")
        if preview_dir:
            os.makedirs(preview_dir, exist_ok=True)
            secs = page.locator("section.slide")
            for i in range(secs.count()):
                secs.nth(i).screenshot(path=os.path.join(preview_dir, f"html_slide_{i + 1:02d}.png"))
        browser.close()

    prs = Presentation(template) if template else Presentation()
    if template and not keep_template_slides:
        _remove_all_slides(prs)
    sw_px, sh_px = slides[0]["w"], slides[0]["h"]
    if not template:
        prs.slide_width = Emu(int(round(sw_px * 12700)))
        prs.slide_height = Emu(int(round(sh_px * 12700)))
    scale = prs.slide_width / sw_px
    ratio_html = sw_px / sh_px
    ratio_ppt = prs.slide_width / prs.slide_height
    if abs(ratio_html - ratio_ppt) > 0.02:
        print(f"  ! aspect ratio differs: html {ratio_html:.3f} vs pptx {ratio_ppt:.3f}. "
              f"Set the slide section to {prs.slide_width / 12700:.0f}x{prs.slide_height / 12700:.0f}px.")
    ctx = Ctx(prs, scale, font, html_dir, default_font)
    layout = _blank_layout(prs)
    counts = {}
    for s in slides:
        slide = prs.slides.add_slide(layout)
        for ph in list(slide.placeholders):
            ph._element.getparent().remove(ph._element)
        rtl = s["rtl"]
        # background
        if s.get("bgGradient"):
            _gradient(slide.background.fill, s["bgGradient"])
        elif s.get("bg"):
            slide.background.fill.solid()
            slide.background.fill.fore_color.rgb = RGBColor.from_string(s["bg"]["hex"].upper())
        if s.get("bgImage"):
            _add_picture(slide, {"box": {"x": 0, "y": 0, "w": s["w"], "h": s["h"]}, "src": s["bgImage"], "fit": "cover"}, ctx)
        for it in sorted(s["items"], key=lambda i: i["z"]):
            k = it["kind"]
            counts[k] = counts.get(k, 0) + 1
            try:
                if k == "shape":
                    _add_shape_item(slide, it, ctx, rtl)
                elif k == "table":
                    _add_table(slide, it, ctx, rtl)
                elif k == "image":
                    _add_picture(slide, it, ctx)
                elif k == "raster":
                    _add_picture(slide, {"box": it["box"], "src": "raster"}, ctx, data=rasters[it["id"]])
                elif k == "chart":
                    b = it["box"]
                    spec = it["spec"]
                    if "error" in spec:
                        print(f"  ! slide {s['index'] + 1}: bad data-chart JSON: {spec['error']}")
                        continue
                    defaults = {"rtl": it.get("rtl", rtl), "font": font or it.get("font") or default_font,
                                "font_size": 12 * scale / 12700}
                    if it.get("color"):
                        defaults["text_color"] = it["color"]["hex"]
                    add_chart(slide, spec, ctx.e(b["x"]), ctx.e(b["y"]), ctx.e(b["w"]), ctx.e(b["h"]), defaults)
            except Exception as ex:
                import traceback
                traceback.print_exc()
                print(f"  ! slide {s['index'] + 1}: failed to add {k}: {ex}")
        if s.get("notes"):
            slide.notes_slide.notes_text_frame.text = s["notes"]
    prs.save(out_path)
    print(f"Saved {out_path}: {len(slides)} slides; objects: " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())))
    return out_path


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("html")
    ap.add_argument("-o", "--out", default=None)
    ap.add_argument("--template", default=None, help="brand .pptx/.potx: its masters, logo and theme are kept")
    ap.add_argument("--font", default=None, help="force one font for every run (e.g. the brand font)")
    ap.add_argument("--default-font", default="Segoe UI", help="font used when CSS gives only a generic family")
    ap.add_argument("--preview", default=None, help="folder for PNG screenshots of the HTML slides")
    ap.add_argument("--keep-template-slides", action="store_true")
    a = ap.parse_args()
    out = a.out or os.path.splitext(a.html)[0] + ".pptx"
    convert(a.html, out, a.template, a.font, a.preview, a.keep_template_slides, a.default_font)


if __name__ == "__main__":
    main()
