#!/usr/bin/env python3
"""
extract_brand.py - Pull colors, fonts and logos out of the user's reference material
so a new deck matches their identity.

    python extract_brand.py file1 [file2 ...] -o brand_dir

Supported inputs:
  .pptx/.potx/.docx/.xlsx  theme colors (dk1, lt1, dk2, lt2, accent1-6), theme fonts
                           (Latin + Arabic/complex-script), most-used colors in slides,
                           slide size, images in masters/layouts (usually the logo)
  .pdf                     dominant colors of the first pages + embedded font names
  .png/.jpg/.svg-less imgs dominant colors (logos, screenshots, brand boards)

Outputs in brand_dir:
  brand.json     everything found, plus a suggested role mapping
  swatches.png   a visual board of the colors - LOOK AT IT before choosing roles
  logo_*.png     images found in slide masters/layouts
"""
import argparse
import collections
import colorsys
import glob
import io
import json
import os
import re
import subprocess
import tempfile
import zipfile

from PIL import Image, ImageDraw

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"


def hex_of(rgb):
    return "#%02X%02X%02X" % tuple(int(v) for v in rgb[:3])


def lum(h):
    h = h.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def sat(h):
    h = h.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return colorsys.rgb_to_hls(r, g, b)[2]


def light(h):
    h = h.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return colorsys.rgb_to_hls(r, g, b)[1]


def is_neutral(h):
    """near-white, near-black or grey: not usable as a brand accent"""
    return sat(h) < 0.12 or light(h) > 0.88 or light(h) < 0.08


def from_office(path, out_dir, result):
    from lxml import etree
    z = zipfile.ZipFile(path)
    names = z.namelist()
    themes = [n for n in names if re.search(r"theme/theme\d+\.xml$", n)]
    info = {"file": os.path.basename(path), "theme_colors": {}, "fonts": {}, "used_colors": {}}
    if themes:
        t = etree.fromstring(z.read(sorted(themes)[0]))
        cs = t.find(f".//{A}clrScheme")
        if cs is not None:
            for el in cs:
                tag = el.tag.replace(A, "")
                c = el.find(f"{A}srgbClr")
                s = el.find(f"{A}sysClr")
                if c is not None:
                    info["theme_colors"][tag] = "#" + c.get("val").upper()
                elif s is not None:
                    info["theme_colors"][tag] = "#" + (s.get("lastClr") or "000000").upper()
        fs = t.find(f".//{A}fontScheme")
        if fs is not None:
            for kind in ("majorFont", "minorFont"):
                k = fs.find(f"{A}{kind}")
                if k is None:
                    continue
                arab = [f.get("typeface") for f in k.findall(f"{A}font") if f.get("script") == "Arab"]
                info["fonts"][kind] = {
                    "latin": (k.find(f"{A}latin").get("typeface") if k.find(f"{A}latin") is not None else None),
                    "complex_script": (k.find(f"{A}cs").get("typeface") if k.find(f"{A}cs") is not None else None) or None,
                    "arabic": arab[0] if arab else None,
                }
    # colors and fonts actually used in content
    counter = collections.Counter()
    fonts = collections.Counter()
    for n in names:
        if re.search(r"(slides/slide|slideMasters/|slideLayouts/|word/document|charts/chart)\w*\d*\.xml$", n):
            x = z.read(n).decode("utf8", "ignore")
            counter.update("#" + v.upper() for v in re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', x))
            fonts.update(re.findall(r'<a:(?:latin|cs) typeface="([^"+][^"]*)"', x))
    info["used_colors"] = dict(counter.most_common(14))
    info["used_fonts"] = dict(fonts.most_common(8))
    # slide size
    if "ppt/presentation.xml" in names:
        p = z.read("ppt/presentation.xml").decode("utf8", "ignore")
        m = re.search(r'sldSz cx="(\d+)" cy="(\d+)"', p)
        if m:
            cx, cy = int(m.group(1)), int(m.group(2))
            info["slide_size_in"] = [round(cx / 914400, 3), round(cy / 914400, 3)]
            info["html_section_px"] = [round(cx / 12700), round(cy / 12700)]
    # logos / images from masters & layouts
    logos = []
    for n in names:
        if re.search(r"ppt/media/.*\.(png|jpe?g|emf|svg|gif)$", n, re.I):
            used_in_master = any(
                n.split("/")[-1] in z.read(r).decode("utf8", "ignore")
                for r in names if re.search(r"ppt/slide(Master|Layout)s/_rels/.*\.rels$", r))
            if used_in_master:
                ext = n.rsplit(".", 1)[1].lower()
                target = os.path.join(out_dir, f"logo_{len(logos) + 1}.{ext}")
                open(target, "wb").write(z.read(n))
                logos.append(target)
    info["master_images"] = logos
    result["office"].append(info)
    result["palette_candidates"].update({k: v for k, v in counter.items()})
    for v in info["theme_colors"].values():
        result["palette_candidates"][v] += 50


def dominant_colors(img, k=10):
    img = img.convert("RGBA")
    img.thumbnail((300, 300))
    bg = Image.new("RGBA", img.size, (255, 255, 255, 255))
    img = Image.alpha_composite(bg, img).convert("RGB")
    q = img.quantize(colors=k, method=Image.Quantize.MEDIANCUT)
    pal = q.getpalette()
    counts = sorted(q.getcolors(), reverse=True)
    total = sum(c for c, _ in counts)
    return [(hex_of(pal[i * 3:i * 3 + 3]), round(c / total, 3)) for c, i in counts]


def from_image(path, result):
    cols = dominant_colors(Image.open(path))
    result["images"].append({"file": os.path.basename(path), "colors": cols})
    for h, share in cols:
        result["palette_candidates"][h] += int(share * 100)


def from_pdf(path, result, pages=4):
    tmp = tempfile.mkdtemp()
    subprocess.run(["pdftoppm", "-png", "-r", "40", "-l", str(pages), path, os.path.join(tmp, "p")], check=False)
    agg = collections.Counter()
    for f in sorted(glob.glob(os.path.join(tmp, "*.png"))):
        for h, share in dominant_colors(Image.open(f), 12):
            agg[h] += share
    fonts = []
    try:
        out = subprocess.run(["pdffonts", path], capture_output=True, text=True).stdout.splitlines()[2:]
        fonts = sorted({re.sub(r"^[A-Z]{6}\+", "", l.split()[0]) for l in out if l.strip()})
    except Exception:
        pass
    result["pdfs"].append({"file": os.path.basename(path), "colors": [(h, round(v, 3)) for h, v in agg.most_common(12)],
                           "fonts": fonts})
    for h, v in agg.items():
        result["palette_candidates"][h] += int(v * 60)


def merge_similar(colors, thresh=28):
    out = []
    for h, w in colors:
        r, g, b = (int(h[i:i + 2], 16) for i in (1, 3, 5))
        for o in out:
            r2, g2, b2 = (int(o[0][i:i + 2], 16) for i in (1, 3, 5))
            if abs(r - r2) + abs(g - g2) + abs(b - b2) < thresh:
                o[1] += w
                break
        else:
            out.append([h, w])
    return sorted(out, key=lambda x: -x[1])


def suggest_roles(result):
    theme = {}
    for o in result["office"]:
        if o["theme_colors"]:
            theme = o["theme_colors"]
            break
    cands = merge_similar(result["palette_candidates"].most_common(40))
    chroma = [h for h, _ in cands if not is_neutral(h)]
    roles = {}
    if theme:
        acc = [theme.get(f"accent{i}") for i in range(1, 7) if theme.get(f"accent{i}")]
        dark = theme.get("dk2") if theme.get("dk2") and not is_neutral(theme["dk2"]) else None
        roles["primary"] = dark or (acc[0] if acc else None)
        rest = [a for a in acc if a != roles["primary"]]
        roles["secondary"] = rest[0] if rest else None
        roles["accent"] = rest[1] if len(rest) > 1 else None
        roles["ink"] = theme.get("dk1")
    else:
        dark_chroma = sorted(chroma, key=lum)
        roles["primary"] = dark_chroma[0] if dark_chroma else "#1F3A5F"
        others = [c for c in chroma if c != roles["primary"]]
        roles["secondary"] = others[0] if others else None
        roles["accent"] = others[1] if len(others) > 1 else None
        roles["ink"] = "#1E293B"
    roles["chart_palette"] = [c for c in [roles.get("primary"), roles.get("secondary"), roles.get("accent")] + chroma if c]
    seen, pal = set(), []
    for c in roles["chart_palette"]:
        if c not in seen:
            seen.add(c); pal.append(c)
    roles["chart_palette"] = pal[:6]
    fonts = {}
    for o in result["office"]:
        if o.get("fonts"):
            mj, mn = o["fonts"].get("majorFont", {}), o["fonts"].get("minorFont", {})
            fonts = {"heading_latin": mj.get("latin"), "body_latin": mn.get("latin"),
                     "arabic": mn.get("arabic") or mn.get("complex_script") or mj.get("arabic")}
            break
    roles["fonts"] = fonts
    return roles


def swatches(result, roles, path):
    cands = merge_similar(result["palette_candidates"].most_common(40))[:18]
    rows = [("Suggested roles", [(k, v) for k, v in roles.items() if isinstance(v, str)]),
            ("Theme", [(k, v) for o in result["office"] for k, v in o["theme_colors"].items()]),
            ("Most used", [(f"{int(w)}", h) for h, w in cands])]
    W, sw = 1200, 90
    H = 40 + sum(40 + ((len(r[1]) + 11) // 12) * (sw + 30) for r in rows)
    im = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(im)
    y = 10
    for title, items in rows:
        d.text((10, y), title, fill="black")
        y += 22
        for i, (label, h) in enumerate(items):
            x = 10 + (i % 12) * (sw + 8)
            yy = y + (i // 12) * (sw + 30)
            d.rectangle([x, yy, x + sw, yy + sw - 20], fill=h, outline="#999999")
            d.text((x, yy + sw - 16), f"{label[:10]} {h}", fill="black")
        y += ((len(items) + 11) // 12) * (sw + 30) + 18
    im.save(path)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+")
    ap.add_argument("-o", "--out", default="brand")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    result = {"office": [], "images": [], "pdfs": [], "palette_candidates": collections.Counter()}
    for f in a.files:
        ext = f.lower().rsplit(".", 1)[-1]
        try:
            if ext in ("pptx", "potx", "docx", "dotx", "xlsx", "xltx", "thmx"):
                from_office(f, a.out, result)
            elif ext == "pdf":
                from_pdf(f, result)
            elif ext in ("png", "jpg", "jpeg", "gif", "bmp", "webp", "tif", "tiff"):
                from_image(f, result)
            else:
                print("skip (unsupported):", f)
        except Exception as ex:
            print("failed:", f, ex)
    roles = suggest_roles(result)
    swatches(result, roles, os.path.join(a.out, "swatches.png"))
    out = dict(result)
    out["palette_candidates"] = [h for h, _ in merge_similar(result["palette_candidates"].most_common(40))[:16]]
    out["suggested"] = roles
    json.dump(out, open(os.path.join(a.out, "brand.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print(json.dumps(roles, ensure_ascii=False, indent=2))
    print("->", os.path.join(a.out, "brand.json"), os.path.join(a.out, "swatches.png"))


if __name__ == "__main__":
    main()
