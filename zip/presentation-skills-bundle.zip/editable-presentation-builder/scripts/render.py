#!/usr/bin/env python3
"""
render.py - Render a .pptx to PNG images (via LibreOffice) for visual QA.

    python render.py deck.pptx out_dir [--dpi 80] [--grid]

Writes out_dir/slide-01.png ... and, with --grid, out_dir/contact_sheet.png
(all slides on one image - fast way to review a whole deck).
Note: LibreOffice draws charts/fonts slightly differently from PowerPoint;
use it to catch overlaps, overflow, empty areas and RTL mistakes.
"""
import argparse
import glob
import os
import shutil
import subprocess
import tempfile

from PIL import Image, ImageDraw


def render(pptx, out_dir, dpi=80, grid=False):
    os.makedirs(out_dir, exist_ok=True)
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, HOME=tmp)
    subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", tmp, os.path.abspath(pptx)],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env, timeout=240)
    pdf = glob.glob(os.path.join(tmp, "*.pdf"))[0]
    for f in glob.glob(os.path.join(out_dir, "slide-*.png")):
        os.remove(f)
    subprocess.run(["pdftoppm", "-png", "-r", str(dpi), pdf, os.path.join(out_dir, "slide")], check=True)
    files = sorted(glob.glob(os.path.join(out_dir, "slide-*.png")))
    # normalise names to slide-01.png
    for f in files:
        n = int(os.path.splitext(f)[0].rsplit("-", 1)[1])
        os.replace(f, os.path.join(out_dir, f"slide-{n:02d}.png"))
    files = sorted(glob.glob(os.path.join(out_dir, "slide-*.png")))
    shutil.copy(pdf, os.path.join(out_dir, "deck.pdf"))
    if grid and files:
        ims = [Image.open(f) for f in files]
        w, h = ims[0].size
        cols = 3 if len(ims) > 4 else 2
        rows = (len(ims) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * (w + 10) + 10, rows * (h + 30) + 10), "#DDDDDD")
        d = ImageDraw.Draw(sheet)
        for i, im in enumerate(ims):
            x, y = 10 + (i % cols) * (w + 10), 10 + (i // cols) * (h + 30)
            sheet.paste(im, (x, y + 20))
            d.text((x, y + 4), f"Slide {i + 1}", fill="black")
        sheet.save(os.path.join(out_dir, "contact_sheet.png"))
    print(f"{len(files)} slides rendered to {out_dir}")
    return files


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("pptx")
    ap.add_argument("out_dir")
    ap.add_argument("--dpi", type=int, default=80)
    ap.add_argument("--grid", action="store_true")
    a = ap.parse_args()
    render(a.pptx, a.out_dir, a.dpi, a.grid)
