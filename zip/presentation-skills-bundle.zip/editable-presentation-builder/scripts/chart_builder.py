#!/usr/bin/env python3
"""
chart_builder.py - Native, editable PowerPoint charts from a small JSON spec.

Every chart is a real PowerPoint chart (right-click -> Edit Data works).
Supports RTL (Arabic) layouts: categories flow right-to-left, value axis on
the right, text runs marked rtl with Arabic complex-script fonts.

Usage as a library:
    from chart_builder import add_chart
    add_chart(slide, spec, x, y, w, h, defaults={"font": "Segoe UI", "rtl": True})

Usage from the command line (adds a chart slide to an existing deck):
    python chart_builder.py deck.pptx spec.json --slide 3 --box 0.5,1.5,12,5.5 [--rtl]
    (box is in inches: left,top,width,height)

Spec (JSON):
{
  "type": "column | bar | line | area | pie | doughnut | scatter |
           stacked_column | stacked_bar | percent_stacked_column |
           percent_stacked_bar | stacked_area | waterfall | combo",
  "categories": ["2022", "2023", "2024"],
  "series": [
     {"name": "Revenue", "values": [100, 120, 150], "color": "#1F3A5F",
      "type": "line",            # combo only: this series drawn as a line
      "axis": "secondary",       # combo only: plot on secondary axis
      "number_format": "0.0%"}   # optional per-series label format
  ],
  "number_format": "#,##0",      # labels + value axis. Percent -> "0.0%"
  "data_labels": true,
  "label_position": "outside_end | inside_end | center | inside_base | above | below | best_fit",
  "legend": "bottom | top | right | left | none",   # default: bottom if >1 series else none
  "title": null,
  "value_axis": {"visible": true, "min": null, "max": null, "gridlines": true, "title": null},
  "category_axis": {"visible": true, "title": null},
  "gap_width": 60, "overlap": null,
  "font_size": 12, "label_font_size": 12,
  "colors": ["#1F3A5F", "#2A9D8F"],    # palette override
  "smooth": false, "markers": true,
  "hole_size": 60,                     # doughnut
  "rtl": null,                         # null = inherit from slide direction
  # waterfall only:
  "totals": [0, 5],                    # indexes of bars that are totals (absolute)
  "up_color": "#2A9D8F", "down_color": "#E76F51", "total_color": "#1F3A5F"
}
"""
import copy
import json
import sys

from lxml import etree
from pptx.chart.data import CategoryChartData, XyChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
from pptx.oxml.ns import qn
from pptx.util import Pt, Emu, Inches

DEFAULT_PALETTE = ["#1F3A5F", "#2A9D8F", "#E9C46A", "#E76F51", "#8D99AE", "#4EA8DE", "#6D597A", "#B5838D"]
AXIS_GRAY = "BFBFBF"
GRID_GRAY = "E7E7E7"
TEXT_GRAY = "595959"

TYPE_MAP = {
    "column": XL_CHART_TYPE.COLUMN_CLUSTERED,
    "bar": XL_CHART_TYPE.BAR_CLUSTERED,
    "stacked_column": XL_CHART_TYPE.COLUMN_STACKED,
    "stacked_bar": XL_CHART_TYPE.BAR_STACKED,
    "percent_stacked_column": XL_CHART_TYPE.COLUMN_STACKED_100,
    "percent_stacked_bar": XL_CHART_TYPE.BAR_STACKED_100,
    "line": XL_CHART_TYPE.LINE_MARKERS,
    "area": XL_CHART_TYPE.AREA,
    "stacked_area": XL_CHART_TYPE.AREA_STACKED,
    "pie": XL_CHART_TYPE.PIE,
    "doughnut": XL_CHART_TYPE.DOUGHNUT,
    "scatter": XL_CHART_TYPE.XY_SCATTER,
}

LABEL_POS = {
    "outside_end": XL_LABEL_POSITION.OUTSIDE_END,
    "inside_end": XL_LABEL_POSITION.INSIDE_END,
    "center": XL_LABEL_POSITION.CENTER,
    "inside_base": XL_LABEL_POSITION.INSIDE_BASE,
    "above": XL_LABEL_POSITION.ABOVE,
    "below": XL_LABEL_POSITION.BELOW,
    "best_fit": XL_LABEL_POSITION.BEST_FIT,
    "left": XL_LABEL_POSITION.LEFT,
    "right": XL_LABEL_POSITION.RIGHT,
}

LEGEND_POS = {
    "bottom": XL_LEGEND_POSITION.BOTTOM,
    "top": XL_LEGEND_POSITION.TOP,
    "right": XL_LEGEND_POSITION.RIGHT,
    "left": XL_LEGEND_POSITION.LEFT,
}


def _hex(c):
    if c is None:
        return None
    c = str(c).strip().lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    return c.upper()


def _rgb(c):
    return RGBColor.from_string(_hex(c))


def _has_arabic(text):
    return any("؀" <= ch <= "ۿ" or "ݐ" <= ch <= "ݿ" or "ﭐ" <= ch <= "﻿" for ch in str(text))


# ---------------------------------------------------------------- text props
def _txpr_xml(size_pt, color, font, rtl, bold=False):
    b = ' b="1"' if bold else ' b="0"'
    rtl_attr = ' rtl="1"' if rtl else ""
    return (
        '<c:txPr xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" '
        'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        '<a:bodyPr/><a:lstStyle/>'
        f'<a:p><a:pPr{rtl_attr}><a:defRPr sz="{int(size_pt * 100)}"{b}>'
        f'<a:solidFill><a:srgbClr val="{_hex(color)}"/></a:solidFill>'
        f'<a:latin typeface="{font}"/><a:ea typeface="{font}"/><a:cs typeface="{font}"/>'
        '</a:defRPr></a:pPr><a:endParaRPr lang="en-US"/></a:p></c:txPr>'
    )


def _set_txpr(parent, size_pt, color, font, rtl, bold=False, before=None):
    """Replace/insert c:txPr on an element (axis, legend, dLbls, chartSpace)."""
    old = parent.find(qn("c:txPr"))
    new = etree.fromstring(_txpr_xml(size_pt, color, font, rtl, bold))
    if old is not None:
        parent.replace(old, new)
        return new
    if before:
        for tag in before:
            ref = parent.find(qn(tag))
            if ref is not None:
                ref.addprevious(new)
                return new
    parent.append(new)
    return new


def _line_props(color=None, width_pt=0.75, none=False):
    a = "http://schemas.openxmlformats.org/drawingml/2006/main"
    if none:
        return f'<a:ln xmlns:a="{a}"><a:noFill/></a:ln>'
    return (f'<a:ln xmlns:a="{a}" w="{int(width_pt * 12700)}"><a:solidFill><a:srgbClr val="{_hex(color)}"/>'
            '</a:solidFill></a:ln>')


def _style_axis_line(axis, color=AXIS_GRAY, none=False):
    fmt = axis.format.line
    if none:
        fmt.fill.background()
    else:
        fmt.color.rgb = _rgb(color)
        fmt.width = Pt(0.75)


# ------------------------------------------------------------------ builders
def _category_data(spec, series_override=None):
    cd = CategoryChartData()
    cd.categories = [str(c) for c in spec.get("categories", [])]
    for s in (series_override or spec["series"]):
        cd.add_series(str(s.get("name", "")), [None if v is None else float(v) for v in s["values"]],
                      number_format=s.get("number_format") or spec.get("number_format"))
    return cd


def _xy_data(spec):
    cd = XyChartData()
    for s in spec["series"]:
        ser = cd.add_series(str(s.get("name", "")))
        for x, y in s["points"]:
            ser.add_data_point(float(x), float(y))
    return cd


def _waterfall_series(spec):
    vals = [float(v) for v in spec["values"]]
    totals = set(spec.get("totals", [0, len(vals) - 1]))
    base, up, down, tot = [], [], [], []
    running = 0.0
    for i, v in enumerate(vals):
        if i in totals:
            running = v
            base.append(0); up.append(None); down.append(None); tot.append(v)
        elif v >= 0:
            base.append(running); up.append(v); down.append(None); tot.append(None)
            running += v
        else:
            running += v
            base.append(running); up.append(None); down.append(-v); tot.append(None)
    names = spec.get("series_names", {})
    return [
        {"name": "_base", "values": base},
        {"name": names.get("up", "Increase"), "values": up},
        {"name": names.get("down", "Decrease"), "values": down},
        {"name": names.get("total", "Total"), "values": tot},
    ]


def add_chart(slide, spec, x, y, w, h, defaults=None):
    """Add a native chart to `slide` at EMU box (x, y, w, h). Returns graphic frame."""
    d = dict(defaults or {})
    ctype = spec.get("type", "column")
    rtl = spec.get("rtl")
    if rtl is None:
        rtl = bool(d.get("rtl"))
        if not rtl:  # auto-detect Arabic content
            probe = " ".join(map(str, spec.get("categories", []))) + " ".join(str(s.get("name", "")) for s in spec.get("series", []))
            rtl = _has_arabic(probe)
    font = spec.get("font") or d.get("font") or "Segoe UI"
    text_color = spec.get("text_color") or d.get("text_color") or TEXT_GRAY
    fsz = spec.get("font_size", d.get("font_size", 12))
    lsz = spec.get("label_font_size", fsz)
    palette = [_hex(c) for c in (spec.get("colors") or d.get("palette") or DEFAULT_PALETTE)]
    numfmt = spec.get("number_format", "#,##0")
    # multi-series lines get crowded with labels: default to axis + gridlines instead
    default_labels = not (spec.get("type") == "line" and len(spec.get("series", [])) > 1) and spec.get("type") != "scatter"
    show_labels = spec.get("data_labels", default_labels)
    spec = dict(spec, data_labels=show_labels)

    # ---------- build chart data
    series_specs = list(spec.get("series", []))
    if ctype == "waterfall":
        series_specs = _waterfall_series(spec)
        chart_type = XL_CHART_TYPE.COLUMN_STACKED
        data = _category_data(spec, series_specs)
    elif ctype == "combo":
        chart_type = XL_CHART_TYPE.COLUMN_CLUSTERED
        data = _category_data(spec)
    elif ctype == "scatter":
        chart_type = XL_CHART_TYPE.XY_SCATTER
        data = _xy_data(spec)
    else:
        chart_type = TYPE_MAP[ctype]
        if ctype == "line" and spec.get("markers") is False:
            chart_type = XL_CHART_TYPE.LINE
        if ctype.startswith("stacked") or ctype.startswith("percent"):
            # zero segments in stacks would show a stray "0" label -> leave them empty
            series_specs = [dict(s, values=[None if (v == 0) else v for v in s["values"]]) for s in series_specs]
            data = _category_data(spec, series_specs)
        else:
            data = _category_data(spec)

    gf = slide.shapes.add_chart(chart_type, Emu(int(x)), Emu(int(y)), Emu(int(w)), Emu(int(h)), data)
    chart = gf.chart
    cs = chart._chartSpace
    # global text defaults
    chart.font.size = Pt(fsz)
    chart.font.name = font
    _set_txpr(cs, fsz, text_color, font, rtl)
    # rounded corners off
    rc = cs.find(qn("c:roundedCorners"))
    if rc is None:
        rc = etree.SubElement(cs, qn("c:roundedCorners"))
        cs.remove(rc)
        cs.insert(0, rc)
    rc.set("val", "0")

    # ---------- title
    if spec.get("title"):
        chart.has_title = True
        tf = chart.chart_title.text_frame
        tf.text = str(spec["title"])
        p = tf.paragraphs[0]
        if rtl:
            p._p.get_or_add_pPr().set("rtl", "1")
        for r in p.runs:
            r.font.size = Pt(fsz + 2); r.font.bold = True; r.font.name = font
            r.font.color.rgb = _rgb(text_color)
            rPr = r._r.get_or_add_rPr()
            etree.SubElement(rPr, qn("a:cs")).set("typeface", font)
    else:
        chart.has_title = False
        atd = cs.chart.find(qn("c:autoTitleDeleted"))
        if atd is not None:
            atd.set("val", "1")

    # ---------- legend
    n_visible_series = len([s for s in series_specs if not str(s.get("name", "")).startswith("_")])
    legend = spec.get("legend")
    if legend is None:
        legend = "bottom" if (n_visible_series > 1 or ctype in ("pie", "doughnut")) and ctype != "waterfall" else "none"
    if legend != "none":
        chart.has_legend = True
        chart.legend.position = LEGEND_POS.get(legend, XL_LEGEND_POSITION.BOTTOM)
        chart.legend.include_in_layout = False
        _set_txpr(chart.legend._element, fsz, text_color, font, rtl)
        if ctype == "waterfall":
            pass
    else:
        chart.has_legend = False

    plot = chart.plots[0]
    is_pie = ctype in ("pie", "doughnut")

    # ---------- series colors
    if is_pie:
        plot.vary_by_categories = True
        ser = plot.series[0]
        pcolors = spec.get("colors") or (series_specs[0].get("colors") if series_specs else None) or palette
        for i in range(len(spec.get("categories", []))):
            pt = ser.points[i]
            pt.format.fill.solid()
            pt.format.fill.fore_color.rgb = _rgb(pcolors[i % len(pcolors)])
            pt.format.line.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            pt.format.line.width = Pt(1.5)
        if ctype == "doughnut":
            hs = cs.find(".//" + qn("c:holeSize"))
            if hs is not None:
                hs.set("val", str(spec.get("hole_size", 60)))
        fsa = cs.find(".//" + qn("c:firstSliceAng"))
        if fsa is not None:
            fsa.set("val", str(spec.get("first_slice_angle", 0)))
    else:
        plot.vary_by_categories = False
        wf_colors = None
        if ctype == "waterfall":
            wf_colors = [None, spec.get("up_color", "#2A9D8F"), spec.get("down_color", "#E76F51"),
                         spec.get("total_color", palette[0])]
        for i, ser in enumerate(plot.series):
            s_spec = series_specs[i] if i < len(series_specs) else {}
            color = _hex(s_spec.get("color")) or palette[i % len(palette)]
            if wf_colors:
                if i == 0:
                    ser.format.fill.background()
                    ser.format.line.fill.background()
                    continue
                color = _hex(wf_colors[i])
            if ctype in ("line",) or (ctype == "scatter"):
                ser.format.line.color.rgb = _rgb(color)
                ser.format.line.width = Pt(spec.get("line_width", 2.5))
                ser.smooth = bool(spec.get("smooth", False))
                try:
                    ser.marker.format.fill.solid()
                    ser.marker.format.fill.fore_color.rgb = _rgb(color)
                    ser.marker.format.line.color.rgb = _rgb(color)
                    ser.marker.size = spec.get("marker_size", 7)
                    from pptx.enum.chart import XL_MARKER_STYLE
                    ser.marker.style = XL_MARKER_STYLE.CIRCLE
                except Exception:
                    pass
            else:
                ser.format.fill.solid()
                ser.format.fill.fore_color.rgb = _rgb(color)
                ser.format.line.fill.background()
            # per-point colors (e.g. highlight one bar)
            for pi, pc in (s_spec.get("point_colors") or {}).items():
                pt = ser.points[int(pi)]
                pt.format.fill.solid()
                pt.format.fill.fore_color.rgb = _rgb(pc)
        if hasattr(plot, "gap_width"):
            try:
                plot.gap_width = int(spec.get("gap_width", 50 if ctype == "waterfall" else 60))
            except Exception:
                pass
        if ctype.startswith("stacked") or ctype.startswith("percent") or ctype == "waterfall":
            try:
                plot.overlap = 100
            except Exception:
                pass
        elif spec.get("overlap") is not None:
            plot.overlap = int(spec["overlap"])
        elif ctype in ("column", "bar", "combo") and len(series_specs) > 1:
            plot.overlap = -10

    # ---------- data labels
    if show_labels:
        pos = spec.get("label_position")
        for i, ser in enumerate(plot.series):
            s_spec = series_specs[i] if i < len(series_specs) else {}
            if ctype == "waterfall" and i == 0:
                continue
            fmt = s_spec.get("number_format") or numfmt
            if ctype == "waterfall" and i == 2:
                # decreases shown in accounting style (12) - reads correctly in LTR and RTL
                fmt = "(" + fmt.split(";")[0] + ")"
            dl = ser.data_labels
            dl.show_value = True
            if is_pie and spec.get("pie_labels", "percent") in ("percent", "both"):
                dl.show_percentage = True
                dl.show_value = spec.get("pie_labels") == "both"
                fmt = spec.get("percent_format", "0.0%")
            if is_pie and spec.get("show_category_on_pie", False):
                dl.show_category_name = True
            dl.number_format = fmt
            dl.number_format_is_linked = False
            lbl_color = text_color
            p = pos
            if p is None:
                if is_pie:
                    p = "outside_end" if ctype == "pie" and spec.get("labels_outside") else ("best_fit" if ctype == "pie" else None)
                elif ctype in ("line", "scatter"):
                    p = "above"
                elif ctype.startswith("stacked") or ctype.startswith("percent") or ctype == "waterfall":
                    p = "center"
                elif ctype in ("area",):
                    p = None
                else:
                    p = "outside_end"
            if p in ("center", "inside_end", "inside_base") and not is_pie:
                lbl_color = spec.get("label_color_inside", "FFFFFF")
            if ctype == "doughnut" or (ctype == "pie" and not spec.get("labels_outside")):
                lbl_color = spec.get("label_color_inside", "FFFFFF")
            if p and p in LABEL_POS:
                try:
                    dl.position = LABEL_POS[p]
                except Exception:
                    pass
            _set_txpr(dl._element, lsz, lbl_color, font, rtl, bold=spec.get("label_bold", is_pie),
                      before=["c:dLblPos", "c:showLegendKey"])
            # hide labels for empty (None) points: blank values produce no label anyway

    # ---------- combo layout: bars in the lower part, line floating above them (no label collisions)
    if ctype == "combo" and any(s.get("axis") == "secondary" for s in series_specs):
        bars = [v for s in series_specs if s.get("type") != "line" for v in s["values"] if v is not None]
        lines = [v for s in series_specs if s.get("type") == "line" for v in s["values"] if v is not None]
        va = dict(spec.get("value_axis") or {})
        if bars and va.get("max") is None and max(bars) > 0:
            va["max"] = max(bars) / 0.62
            if min(bars) >= 0 and va.get("min") is None:
                va["min"] = 0
            spec = dict(spec, value_axis=va)
        sa = dict(spec.get("secondary_axis") or {})
        if lines and sa.get("min") is None and sa.get("max") is None:
            lo, hi = min(lines), max(lines)
            span = (hi - lo) or abs(hi) * 0.1 or 1
            sa["min"] = round(lo - span * 0.72 / 0.23, 6)
            sa["max"] = round(hi + span * 0.05 / 0.23, 6)
            spec = dict(spec, secondary_axis=sa)

    # ---------- axes (before combo, so python-pptx sees only the primary axes)
    if not is_pie:
        _style_axes(chart, spec, ctype, font, text_color, fsz, numfmt, rtl)

    # ---------- combo: move line series into a lineChart on its own axes
    if ctype == "combo":
        _make_combo(chart, spec, series_specs, palette, font, text_color, fsz, lsz, numfmt, rtl, show_labels)

    # waterfall legend: drop the base series entry
    if ctype == "waterfall" and chart.has_legend:
        leg = chart.legend._element
        le = etree.SubElement(leg, qn("c:legendEntry"))
        leg.remove(le)
        etree.SubElement(le, qn("c:idx")).set("val", "0")
        etree.SubElement(le, qn("c:delete")).set("val", "1")
        leg.insert(1, le)
    return gf


def _style_axes(chart, spec, ctype, font, text_color, fsz, numfmt, rtl):
    va_spec = spec.get("value_axis", {}) or {}
    ca_spec = spec.get("category_axis", {}) or {}
    horizontal = ctype in ("bar", "stacked_bar", "percent_stacked_bar")
    try:
        cat = chart.category_axis
    except Exception:
        cat = None
    val = chart.value_axis

    # value axis
    val.has_major_gridlines = va_spec.get("gridlines", not spec.get("data_labels", True) or ctype in ("line", "scatter", "combo", "area", "stacked_area"))
    if val.has_major_gridlines:
        gl = val.major_gridlines.format.line
        gl.color.rgb = _rgb(GRID_GRAY)
        gl.width = Pt(0.75)
    from pptx.enum.chart import XL_TICK_MARK, XL_TICK_LABEL_POSITION
    val.major_tick_mark = XL_TICK_MARK.NONE
    val.minor_tick_mark = XL_TICK_MARK.NONE
    if va_spec.get("min") is not None:
        val.minimum_scale = float(va_spec["min"])
    if va_spec.get("max") is not None:
        val.maximum_scale = float(va_spec["max"])
    vfmt = va_spec.get("number_format") or ("0%" if ctype.startswith("percent") else numfmt)
    val.tick_labels.number_format = vfmt
    val.tick_labels.number_format_is_linked = False
    _style_axis_line(val, none=True)
    visible_default = not spec.get("data_labels", True) or ctype in ("line", "scatter", "area", "stacked_area")
    if not va_spec.get("visible", visible_default):
        val.tick_label_position = XL_TICK_LABEL_POSITION.NONE
    _set_txpr(val._element, fsz, text_color, font, rtl, before=["c:crossAx"])
    if va_spec.get("title"):
        val.has_title = True
        val.axis_title.text_frame.text = va_spec["title"]

    if cat is not None:
        cat.major_tick_mark = XL_TICK_MARK.NONE
        cat.minor_tick_mark = XL_TICK_MARK.NONE
        _style_axis_line(cat, color=AXIS_GRAY)
        if ca_spec.get("visible") is False:
            cat.tick_label_position = XL_TICK_LABEL_POSITION.NONE
        _set_txpr(cat._element, fsz, text_color, font, rtl, before=["c:crossAx"])
        if ca_spec.get("title"):
            cat.has_title = True
            cat.axis_title.text_frame.text = ca_spec["title"]
        cat.has_major_gridlines = False

    # --- orientation / RTL mirroring
    def orient(axis_el, value):
        sc = axis_el.find(qn("c:scaling"))
        o = sc.find(qn("c:orientation"))
        if o is None:
            o = etree.SubElement(sc, qn("c:orientation"))
        o.set("val", value)

    if ctype == "scatter":
        if rtl:
            # x axis is a valAx too; reverse the first valAx (x)
            axes = chart._chartSpace.findall(".//" + qn("c:valAx"))
            if axes:
                orient(axes[0], "maxMin")
        return
    if cat is None:
        return
    if horizontal:
        # first category at the top (reading order)
        orient(cat._element, "maxMin")
        if rtl:
            # bars grow from right to left; category labels sit on the right
            orient(val._element, "maxMin")
    else:
        if rtl:
            # first category on the right; value axis moves to the right side
            orient(cat._element, "maxMin")
    # when the category axis is reversed, keep the value axis crossing at the category start
    # and keep the category axis at the bottom for column charts
    if horizontal:
        # with a reversed category axis the value axis would jump to the top;
        # make it cross the category axis at the last (bottom) category
        c = val._element.find(qn("c:crosses"))
        if c is not None:
            c.set("val", "max")


def _make_combo(chart, spec, series_specs, palette, font, text_color, fsz, lsz, numfmt, rtl, show_labels):
    C = "http://schemas.openxmlformats.org/drawingml/2006/chart"
    plotArea = chart._chartSpace.find(".//" + qn("c:plotArea"))
    bar = plotArea.find(qn("c:barChart"))
    sers = bar.findall(qn("c:ser"))
    line_idx = [i for i, s in enumerate(series_specs) if s.get("type") == "line"]
    if not line_idx:
        return
    secondary = any(series_specs[i].get("axis") == "secondary" for i in line_idx)
    bar_axids = [a.get("val") for a in bar.findall(qn("c:axId"))]
    if secondary:
        ax_cat, ax_val = "50010", "50020"
    else:
        ax_cat, ax_val = bar_axids
    line = etree.Element(qn("c:lineChart"))
    etree.SubElement(line, qn("c:grouping")).set("val", "standard")
    etree.SubElement(line, qn("c:varyColors")).set("val", "0")
    for i in line_idx:
        ser = sers[i]
        bar.remove(ser)
        s_spec = series_specs[i]
        color = _hex(s_spec.get("color")) or palette[i % len(palette)]
        inv = ser.find(qn("c:invertIfNegative"))
        if inv is not None:
            ser.remove(inv)
        sp = ser.find(qn("c:spPr"))
        if sp is not None:
            ser.remove(sp)
        sp = etree.fromstring(
            f'<c:spPr xmlns:c="{C}" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
            f'<a:ln w="{int(spec.get("line_width", 2.5) * 12700)}" cap="rnd"><a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
            '<a:round/></a:ln></c:spPr>')
        tx = ser.find(qn("c:tx"))
        tx.addnext(sp)
        marker = etree.fromstring(
            f'<c:marker xmlns:c="{C}" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
            '<c:symbol val="circle"/><c:size val="7"/>'
            f'<c:spPr><a:solidFill><a:srgbClr val="{color}"/></a:solidFill><a:ln><a:solidFill><a:srgbClr val="{color}"/></a:solidFill></a:ln></c:spPr>'
            '</c:marker>')
        sp.addnext(marker)
        dl = ser.find(qn("c:dLbls"))
        if dl is not None:
            pos = dl.find(qn("c:dLblPos"))
            if pos is not None:
                pos.set("val", "t")
            # labels of the line sit above the points; use series color for readability
            _set_txpr(dl, lsz, color, font, rtl, bold=True, before=["c:dLblPos", "c:showLegendKey"])
        etree.SubElement(ser, qn("c:smooth")).set("val", "0")
        line.append(ser)
    etree.SubElement(line, qn("c:marker")).set("val", "1")
    etree.SubElement(line, qn("c:axId")).set("val", ax_cat)
    etree.SubElement(line, qn("c:axId")).set("val", ax_val)
    bar.addnext(line)

    if secondary:
        last_ax = plotArea.findall(qn("c:valAx"))[-1]
        sec_fmt = next((series_specs[i].get("number_format") for i in line_idx if series_specs[i].get("number_format")), numfmt)
        cat_xml = (f'<c:catAx xmlns:c="{C}"><c:axId val="{ax_cat}"/><c:scaling><c:orientation val="{"maxMin" if rtl else "minMax"}"/></c:scaling>'
                   f'<c:delete val="1"/><c:axPos val="b"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/>'
                   f'<c:tickLblPos val="nextTo"/><c:crossAx val="{ax_val}"/><c:crosses val="min"/>'
                   '<c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:noMultiLvlLbl val="0"/></c:catAx>')
        show_sec = (spec.get("secondary_axis", {}) or {}).get("visible", False)
        val_xml = (f'<c:valAx xmlns:c="{C}" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><c:axId val="{ax_val}"/><c:scaling><c:orientation val="minMax"/>'
                   + (f'<c:max val="{spec["secondary_axis"]["max"]}"/>' if (spec.get("secondary_axis") or {}).get("max") is not None else "")
                   + (f'<c:min val="{spec["secondary_axis"]["min"]}"/>' if (spec.get("secondary_axis") or {}).get("min") is not None else "")
                   + f'</c:scaling><c:delete val="0"/><c:axPos val="{"l" if rtl else "r"}"/>'
                   f'<c:numFmt formatCode="{sec_fmt}" sourceLinked="0"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/>'
                   f'<c:tickLblPos val="{"nextTo" if show_sec else "none"}"/><c:spPr><a:ln><a:noFill/></a:ln></c:spPr>'
                   f'<c:crossAx val="{ax_cat}"/><c:crosses val="max"/><c:crossBetween val="between"/></c:valAx>')
        cat_el = etree.fromstring(cat_xml)
        val_el = etree.fromstring(val_xml)
        last_ax.addnext(cat_el)
        cat_el.addnext(val_el)
        _set_txpr(val_el, fsz, text_color, font, rtl, before=["c:crossAx"])
        # headroom so line labels don't collide with bars
        if (spec.get("secondary_axis") or {}).get("min") is None:
            pass


# ---------------------------------------------------------------- CLI
def _main():
    import argparse
    from pptx import Presentation
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pptx")
    ap.add_argument("spec")
    ap.add_argument("--slide", type=int, default=None, help="1-based slide index; omit to append a blank slide")
    ap.add_argument("--box", default="0.6,1.5,12.1,5.4", help="left,top,width,height in inches")
    ap.add_argument("--rtl", action="store_true")
    ap.add_argument("--font", default="Segoe UI")
    ap.add_argument("-o", "--out", default=None)
    a = ap.parse_args()
    prs = Presentation(a.pptx)
    spec = json.load(open(a.spec, encoding="utf-8"))
    if a.slide:
        slide = prs.slides[a.slide - 1]
    else:
        layout = min(prs.slide_layouts, key=lambda l: len(l.placeholders))
        slide = prs.slides.add_slide(layout)
    l, t, w, h = [Inches(float(v)) for v in a.box.split(",")]
    add_chart(slide, spec, l, t, w, h, {"rtl": a.rtl, "font": a.font})
    prs.save(a.out or a.pptx)
    print("saved", a.out or a.pptx)


if __name__ == "__main__":
    _main()
