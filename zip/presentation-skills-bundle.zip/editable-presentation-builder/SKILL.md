---
name: editable-presentation-builder
description: Build professional, fully EDITABLE PowerPoint presentations (.pptx) by designing the slides in HTML/CSS and converting them to native PowerPoint objects - real text boxes, shapes, tables and native charts, not pictures. Supports Arabic right-to-left decks and applies the colors, fonts and logo of any brand files the user provides. Use this skill whenever the user asks for a presentation, deck, slides, pitch deck, board or bank presentation, business plan deck, or says برزنتيشن، عرض تقديمي، شرائح، باوربوينت، بوربوينت - even if they don't mention HTML or editability. Prefer it over building slides directly with python-pptx.
---

# Editable Presentation Builder

HTML is the design surface (flexbox, grids, precise typography, easy to iterate); `scripts/html2pptx.py`
measures the rendered page in Chromium and rebuilds every element as a native PowerPoint object.
The result looks like the design but stays 100% editable: the user can retype text, recolor shapes,
and right-click → Edit Data on charts.

Companion skills (use them if installed):
- **presentation-charts-infographics** - choosing and specifying charts, KPI tiles, process/timeline graphics.
- **professional-business-writing** - slide titles, bullets, Arabic/English wording, number formatting.

## Workflow

### 1. Understand the material
Read everything the user gives (Excel, PDF, Word, notes). Extract the actual figures - never invent
numbers. Decide the audience (bank, board, management, investors) and the one-line message of the deck.
Note the language: an Arabic request means an Arabic, right-to-left deck.

### 2. Capture the brand (whenever the user supplies files)
If the user attached a template, old presentation, logo, brand guide or report, use its identity:
```bash
python scripts/extract_brand.py <files...> -o brand/
```
Then **look at `brand/swatches.png`** and `brand/brand.json`, and decide the roles yourself:
`--primary` (titles, main bars, header rows), `--secondary`, `--accent` (one highlight per slide),
text colors, fonts (Arabic font from `fonts.arabic` if present). Logos found in masters are saved as
`brand/logo_*.png` - place the logo on the title slide and (small) on content slides.

If the user gave a real `.pptx/.potx` template, you can also convert **into** it with
`--template file.pptx`: its masters, backgrounds and logo stay, its old slides are removed, and your
content goes on its blank layout. Render one of its slides first to see where master decorations sit,
keep content out of those zones, and set `--bg: transparent` in the HTML so the master background shows.
Match the section size to `html_section_px` from brand.json if the template isn't 16:9.

No brand files → keep the neutral professional palette in `assets/template.html`.

### 3. Plan the storyline before designing
Write a slide list: for each slide an **action title** (a full sentence stating the conclusion, e.g.
"الإيرادات نمت 18.0% بدعم زيادة الكميات") and the evidence (chart, table, KPIs, 3-5 bullets).
One message per slide. Typical bank/board deck: title → executive summary (KPIs) → market/company →
historical performance → projections → funding need & use of funds → risks & mitigants → closing ask.
See `references/design-guide.md` for layouts that fit each slide type.

### 4. Write the HTML
Start from a copy of `assets/template.html` (it contains the CSS design system and sample
slides: title, KPI cards, chart + notes, table, chevron process). Rules that matter most - the full
list is in `references/html-rules.md`, read it before your first deck:

- One `<section class="slide">` per slide, **960×540 px** (1 px = 1 pt in PowerPoint).
- Put all text inside elements (`h1-h3`, `p`, `li`, `span`, `td`). Text in `::before/::after` is lost.
- Charts: `<div data-chart='{...json...}'></div>` → native chart. Spec in `references/chart-spec.md`.
- Infographic shapes: `data-shape="chevron|arrow-right|pentagon|hexagon|..."` → PowerPoint preset shapes.
- Icons: inline `<svg>` (becomes a sharp PNG). Photos: `<img>` with `object-fit: cover`.
- Speaker notes: `<aside class="notes">…</aside>` inside the slide.
- Use hex colors, px sizes, no CSS transforms/animations.
- Nothing may overflow the 960×540 box; leave ≥ 40 px margins.

### 5. Convert and check visually - always
```bash
python scripts/html2pptx.py deck.html -o deck.pptx --preview preview/     # add --template brand.pptx if any
python scripts/render.py deck.pptx render/ --grid                          # PowerPoint → PNGs via LibreOffice
```
Open `render/contact_sheet.png`, then individual slides that look suspicious. Check: text overflowing
or wrapping badly, overlaps, empty areas, chart labels colliding, RTL direction (Arabic text right
aligned, first category on the right, process flowing right→left), numbers formatted correctly.
Fix the HTML and re-run. Do at least one fix-and-recheck pass; most decks need two.

LibreOffice renders fonts slightly differently from PowerPoint; judge layout, not exact glyphs.

### 6. Deliver
Deliver the `.pptx` (not the HTML) and mention in one line that everything is editable and which
font the deck uses (if it's a brand font the recipient must have it installed).

## Arabic / RTL decks

Direction must be right-to-left everywhere, not only the text:
- `<html dir="rtl" lang="ar">`. Use logical CSS (`inset-inline-start`, `padding-inline-start`,
  `text-align: start`) so the same classes work in both directions.
- Reading order starts at the **right**: logo/kicker/title aligned right, first KPI card on the right,
  timelines and processes flow right→left (chevrons get `data-flip-h` so they point left), step 1 on the right.
- Tables: first column (labels) on the right - happens automatically with `dir="rtl"`; the converter
  writes an RTL PowerPoint table.
- Charts: automatically mirrored for RTL (first category on the right, value axis on the right,
  horizontal bars grow from the right). Don't reverse the data yourself.
- Numbers use Western digits (1,250 / 18.0%). Ranges read right-to-left: write "من 10.0% إلى 15.0%"
  or "10.0% – 15.0%" with spaces around an en dash; the converter normalises `10%-15%` to that form.
- In Arabic text a trailing percent is shown on the left of the number (`%25.0`) by the bidi algorithm
  in both the browser and PowerPoint; that's the normal Arabic rendering, don't fight it.
- Mixed English terms (EBITDA, DSCR) are fine inside Arabic sentences.

## Number and table conventions (defaults for this user)
- Amounts: thousands separator, **no decimals** (1,250). Negative amounts in parentheses (838).
- Percentages: **one decimal** (18.0%). Chart specs: `"number_format": "#,##0"` / `"0.0%"`.
- Numbers and percentages are **centered** in table cells (template does this); labels align to start.
- State the unit in the title or header (مليون جنيه / EGP m) instead of repeating it in cells.
- Every slide with data carries a source line (`<p class="source">المصدر: …</p>`).

## Troubleshooting
- A shape is missing → it had no background/border, or its content came from a pseudo-element.
- Text wraps differently in PowerPoint → give the box more width or shorten the text; don't rely on
  a line ending at an exact word.
- `aspect ratio differs` warning → the HTML section size doesn't match the template's slide size.
- Chart looks wrong → validate the JSON (single quotes around the attribute, double quotes inside).
- Need to add a chart to an existing pptx without HTML → `python scripts/chart_builder.py deck.pptx spec.json --slide 3 --rtl`.

## Files
- `scripts/html2pptx.py` - the converter (needs `playwright`, `python-pptx`, `Pillow`).
- `scripts/chart_builder.py` - native chart engine used by the converter; also a CLI.
- `scripts/extract_brand.py` - colors/fonts/logos from pptx, potx, docx, xlsx, pdf, images.
- `scripts/render.py` - pptx → PNG slides + contact sheet for QA.
- `assets/template.html` - starting deck with the CSS design system.
- `references/html-rules.md` - exactly what converts to what; read before writing HTML.
- `references/design-guide.md` - layouts per slide type, typography scale, color use.
- `references/chart-spec.md` - JSON spec for `data-chart`.
