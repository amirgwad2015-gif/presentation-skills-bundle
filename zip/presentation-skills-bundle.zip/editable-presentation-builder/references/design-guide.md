# Design guide for business decks

## Principles
1. **One message per slide.** The title states it as a sentence; the body proves it.
2. **Show, don't list.** Numbers → chart, KPI tile or table. Steps → process shapes. Periods → timeline.
   Plain bullet slides only when the content really is a list, max 5 bullets.
3. **Consistency.** Same title position, margins, colors and fonts on every slide. The template's
   CSS classes enforce this - reuse them instead of inline one-offs.
4. **Restraint with color.** Primary color for structure, secondary for comparison, ONE accent to
   highlight the key number on the slide. Red/orange (`--negative`) only for declines and risks.
5. **Whitespace.** 56 px side margins, ≥ 20 px between blocks. A slide that is 60% full looks professional.
6. **Every number has a unit and a source.**

## Type scale (px = pt)
| Role | Size / line-height | Weight |
|---|---|---|
| Title slide heading | 40 / 52 | 700 |
| Slide title (action title) | 24-26 / 34-36 | 700 |
| Kicker (section label above title) | 13 / 18 | 700, secondary color |
| Sub-heading / card title | 16-17 / 24 | 700 |
| Body / bullets | 14-16 / 22-24 | 400 |
| KPI value | 30-36 / 40-44 | 700 |
| Table text | 12-13 / 18 | 400, header 700 |
| Source / footnote / page no. | 10 / 14 | 400, muted |

Arabic text needs slightly more line-height than English (≥ 1.5× for body). Avoid all-caps for English
headings in Arabic decks. Don't use italics for Arabic.

## Layout patterns per slide type
- **Title** - full-bleed primary background, title + subtitle + date/audience, logo. Optional side band.
- **Section divider** - big section number + name, primary background.
- **Executive summary** - 3-4 KPI cards in a row + one "key message" bar (template slide 2), or
  3 numbered takeaways each with a bold lead-in.
- **Chart + insight** - chart takes 2/3 width; 1/3 card with 2-4 short observations (template slide 3).
  In RTL the chart can sit on the left and the insight card on the right (reader starts with the insight).
- **Table** - full width, header row in primary color, total row bold on soft background, numbers
  centered, labels start-aligned, negative numbers in parentheses, a variance column colored pos/neg.
- **Comparison** - two columns (before/after, option A/B, budget/actual) with matching structure.
- **Process / roadmap** - chevrons or numbered circles with a line, 3-6 steps, one-line caption each.
- **Timeline** - horizontal line with dated milestones; in Arabic the earliest date is on the right.
- **Funding / sources & uses** - two stacked bars or two tables side by side + total.
- **Risk matrix** - table: risk | impact | mitigation, impact as colored pill (high/medium/low).
- **Closing / the ask** - the request in one big sentence + 3 supporting facts + contact.

## Colors
Default palette (template `:root`): primary #1F3A5F navy, secondary #2A9D8F teal, accent #E9C46A
gold, negative #E76F51, ink #1E293B, muted #64748B, line #E2E8F0, soft #F1F5F9.

With a brand: primary = the darkest saturated brand color (good for titles and header rows), secondary
= the second brand color, accent = a bright brand color used sparingly. Check contrast: white text
needs a dark background; don't put body text in a light brand color. Derive tints for card
backgrounds (mix the primary with white ~8%) rather than inventing new hues.

## Images and icons
- Logos: `<img>` with explicit width, `object-fit: contain`.
- Icons: simple inline SVG strokes in the primary color, same size across a slide (24-32 px).
- Photos: only when they add information (plant, product); crop with `object-fit: cover`.

## Final checklist
- [ ] Every title is a conclusion sentence, ≤ 2 lines
- [ ] No text smaller than 10 px; body ≥ 14 px
- [ ] Nothing touches the slide edge or overlaps
- [ ] Units + source on every data slide
- [ ] Numbers: no decimals for amounts, 1 decimal for %, centered in tables
- [ ] Arabic deck: everything starts on the right (titles, flow, first column, first category)
- [ ] Brand colors/fonts applied if files were provided
- [ ] Slide numbers on content slides
