# `data-chart` JSON spec

```html
<div style="width:600px;height:360px" data-chart='{"type":"column","categories":["2023","2024","2025"],
  "series":[{"name":"الإيرادات","values":[810,1060,1250]}],"number_format":"#,##0"}'></div>
```
Wrap the attribute in single quotes and use double quotes inside. Apostrophes in labels: write `&#39;`.
The div needs a real size (explicit or from flex/grid).

## Types
| type | use for |
|---|---|
| `column` / `bar` | compare values across categories (bar = long labels or ranking) |
| `stacked_column` / `stacked_bar` | composition + total |
| `percent_stacked_column` / `percent_stacked_bar` | mix/share over time (values can be raw or shares) |
| `line` | trends over time (≥ 4 periods), several series |
| `area` / `stacked_area` | cumulative volume trends |
| `pie` / `doughnut` | share of one total, ≤ 5 slices |
| `combo` | bars + line (e.g. revenue + margin %). Line series: `"type":"line"`, add `"axis":"secondary"` for a different scale |
| `waterfall` | bridge from A to B (EBITDA bridge, cash-flow walk) - uses `values` + `totals` instead of series |
| `scatter` | two numeric variables; series use `"points": [[x,y],...]` |

## Keys
| key | default | notes |
|---|---|---|
| `categories` | - | labels on the category axis |
| `series` | - | `[{"name","values","color"?,"number_format"?,"point_colors"?:{"2":"#E9C46A"}}]` |
| `number_format` | `"#,##0"` | Excel format for labels and value axis. `"0.0%"` for percentages (values as fractions: 0.182). `"#,##0,"` shows thousands. |
| `data_labels` | true (false for multi-series line/scatter) | value labels |
| `label_position` | auto | `outside_end inside_end center inside_base above below best_fit` |
| `legend` | bottom if > 1 series | `top bottom right left none` |
| `title` | none | prefer the slide title over a chart title |
| `value_axis` | hidden when labels are shown | `{"visible", "min", "max", "gridlines", "number_format", "title"}` |
| `category_axis` | `{}` | `{"visible": false}` to hide, `"title"` |
| `secondary_axis` | auto-scaled | combo only: `{"min","max","visible"}` |
| `colors` | brand/default palette | list of hex, applied per series (per slice for pie) |
| `gap_width` | 60 | bar thickness (lower = thicker) |
| `font_size` / `label_font_size` | 12 | pt |
| `rtl` | from the div's direction | force `true/false` |
| `hole_size` | 60 | doughnut |
| `pie_labels` | `"percent"` | `"value"`, `"percent"`, `"both"`; `show_category_on_pie: true` adds names |
| `smooth`, `markers`, `line_width` | false, true, 2.5 | line charts |
| waterfall | | `"values":[start, +d1, -d2, ..., end]`, `"totals":[0, last]` (absolute bars), `"up_color","down_color","total_color"`, `"series_names":{"up":"زيادة","down":"نقص","total":"الإجمالي"}` |

Use `null` for a missing value (no bar, no label). Zero segments in stacked charts are left empty automatically.

Highlight one bar: `"point_colors": {"3": "#E9C46A"}` on the series (index is 0-based).

Waterfall decreases are labelled in accounting style `(22)`, which reads correctly in both directions.
Waterfall assumes the running total stays above zero.
