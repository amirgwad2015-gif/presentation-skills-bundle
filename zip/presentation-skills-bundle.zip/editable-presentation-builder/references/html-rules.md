# HTML → PowerPoint conversion rules

The converter walks the DOM of each `<section class="slide">` in document order (earlier = further
back in PowerPoint) and decides for each element:

| HTML | Becomes in PowerPoint |
|---|---|
| Element whose children are only text + inline tags (`b strong i em u span a br sup sub small`) | One text box. Each inline style (color, bold, size, font) becomes its own run. |
| Same element with background / border / radius / shadow | One shape with the text inside it (padding → text insets). |
| `ul` / `ol` whose `li`s contain only inline content | One text box, one paragraph per `li`, real bullets/numbering, nested lists → indent levels. `li::marker` color → bullet color. `data-bullet="✓"` on an `li` sets a custom bullet. |
| Container (`div`, `section`, `li` with block children) with background/border | A shape behind its children; then children are processed. |
| Container without decoration | Nothing - only its children. |
| `border-radius` | Rounded rectangle; ≥ 50% on a square → ellipse. |
| Only some borders (e.g. `border-bottom`) | Separate line objects. Uniform borders → shape outline. |
| `background: linear-gradient(...)` | Gradient fill (angle + stops). Other gradient types are ignored. |
| `box-shadow` | Soft outer shadow. |
| `rgba()` / `opacity` | Fill transparency. |
| `data-shape="…"` | PowerPoint preset shape (list below). Add `data-flip-h` / `data-flip-v` to mirror, `data-adj="0.3"` to set the preset's adjustment handle. |
| `<table>` | Native table: column widths/row heights as rendered, `colspan/rowspan` merged, per-cell fill, text color, bold, alignment, vertical-align, padding, per-side borders. RTL when `dir=rtl`. Table style is "No Style" so only your CSS shows. |
| `<div data-chart='{json}'>` | Native chart filling the div box (see chart-spec.md). The div's color/font are used as chart text defaults. Children are ignored. |
| `<img>` | Picture. `object-fit: cover` → cropped, `contain` → letterboxed, border-radius → rounded/elliptical crop. |
| `<svg>`, `<canvas>`, any element with `data-raster` | Screenshot at 3× → PNG picture (sharp, but not editable). Use for icons and complex art only. |
| `section.slide` background color / gradient / `url()` | Slide background. |
| `<aside class="notes">` | Speaker notes (not drawn). |
| `data-name="…"` | Shape name in the Selection Pane (useful for the user). |

Preset shapes for `data-shape`: `rect rounded ellipse circle chevron pentagon homeplate arrow-right
arrow-left arrow-up arrow-down notched-arrow-right triangle right-triangle diamond hexagon octagon
parallelogram trapezoid star donut block-arc pie chord callout round-callout snip round-1
round-2-diag plus flowchart-process cloud wave frame teardrop`.
In the HTML preview a preset shape is just a box - use `clip-path` (as the template's `.chev` does)
if you want the preview to resemble it; the converter ignores clip-path and uses the preset.

## What is NOT converted - avoid or work around
- `::before` / `::after` content (text, icons, decorative bars) → use real elements.
- `transform` (rotate/scale/translate), animations, filters, blend modes, `backdrop-filter`.
- Radial/conic gradients, multiple backgrounds, `background-clip:text`.
- Text inside `inline-block` elements mixed with other text: the inline-block becomes a separate box.
  Keep a paragraph's text in one element with inline tags only.
- `writing-mode`, vertical text, CSS columns.
- Colors in `oklch()`, `lab()`, `color-mix()` - use hex or rgb.
- Web fonts that are not installed in PowerPoint. Use a font the user has (Windows: Segoe UI, Arial,
  Tahoma, Calibri, Sakkal Majalla, Traditional Arabic; Office also ships "Dubai"), or the brand font.
  The browser preview may substitute a different font; the PPTX names the font you wrote in CSS.

## Sizing rules
- Slide = 960×540 px (16:9). Other sizes work: everything scales to the output slide width.
- Font sizes in px = points in PowerPoint. Minimums: body 14, table/labels 11-12, source line 10.
- Set explicit `line-height` in px for text classes: PowerPoint receives exact line spacing.
- Give text boxes spare width (~10%): PowerPoint's font metrics differ slightly from Chromium's.
- Fixed heights on text containers can clip in the browser but not in PowerPoint; better to size by content.

## Direction
- The converter reads the computed `direction` of every paragraph, table and chart div.
  `dir="rtl"` on `<html>` covers the whole deck; `dir="ltr"` on an element switches it back
  (e.g. an English quote or code inside an Arabic deck).
- `text-align: start/end` are resolved per direction.
- Arabic runs are tagged `lang="ar-EG"` with the font applied to the complex-script slot too,
  so PowerPoint doesn't swap in a fallback font for Arabic letters.
